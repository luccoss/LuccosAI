from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile, ZIP_DEFLATED, ZIP_STORED
from html import escape
from html import escape as x
import csv, io, json, re, subprocess
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.utils import get_column_letter
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.pagesizes import A5
from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer, Preformatted
from pypdf import PdfReader
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE
from pptx.dml.color import RGBColor
from pptx.util import Inches, Pt

here=Path(__file__).resolve().parent
root=here.parent/'lucco-store'
media=root/'public/media'
files=root/'downloads'
fonts=Path('/usr/share/fonts/truetype/dejavu')
for path in (media,files): path.mkdir(parents=True,exist_ok=True)
for font,file in [('LuccoSerif','DejaVuSerif.ttf'),('LuccoSans','DejaVuSans.ttf'),('LuccoBold','DejaVuSans-Bold.ttf')]:
    pdfmetrics.registerFont(TTFont(font,str(fonts/file)))
genres={
 'ai':('AI en digitale vaardigheden','#363d49','#b5bdca'),
 'business':('Ondernemen en freelancen','#2c473f','#bac6b8'),
 'geld':('Geld en budget','#40332d','#c9b19b'),
 'productiviteit':('Productiviteit en zelfontwikkeling','#383850','#c2bccd'),
 'welzijn':('Voeding en welzijn','#3d4537','#c2c5aa'),
 'content':('Marketing en creatie','#613b36','#d3b9ae'),
 'leven':('Levensfasen','#615448','#e1cabb'),
 'techniek':('Techniek en ontwerp','#293a45','#b8c5cd'),
 'thriller':('Thrillers','#292831','#a59da6'),
 'romantiek':('Romantiek','#623945','#d3abb8')
}
kinds={'ebook':'E-book','template':'Template','course':'Mini-cursus'}
sources={
'beleggen-in-begrippen':('Autoriteit Financiële Markten – Praktische checklist bij beleggen','https://www.afm.nl/nl-nl/consumenten/themas/zelf-beleggen/is-beleggen-iets-voor-jou/praktische-checklist-bij-beleggen'),
'slaapdagboek-gids':('Thuisarts – Slaapdagboek invullen','https://www.thuisarts.nl/slecht-slapen/slaapdagboek-invullen'),
'slaaplog-sheet':('Thuisarts – Slaapdagboek invullen','https://www.thuisarts.nl/slecht-slapen/slaapdagboek-invullen'),
'weekmenu-vlot':('Voedingscentrum – Veilig omgaan met kliekjes','https://www.voedingscentrum.nl/nl/thema/5xveilig/Kliekjes.aspx'),
'weekmenu-sheet':('Voedingscentrum – Veilig omgaan met kliekjes','https://www.voedingscentrum.nl/nl/thema/5xveilig/Kliekjes.aspx'),
'maaltijdvoorbereiding':('Voedingscentrum – Veilig omgaan met kliekjes','https://www.voedingscentrum.nl/nl/thema/5xveilig/Kliekjes.aspx'),
'cursus-weekmenu':('Voedingscentrum – Veilig omgaan met kliekjes','https://www.voedingscentrum.nl/nl/thema/5xveilig/Kliekjes.aspx')
}
html_example='<!doctype html>\n<html lang="nl">\n<head>\n  <meta charset="utf-8">\n  <meta name="viewport" content="width=device-width,initial-scale=1">\n  <title>Mijn proefpagina</title>\n  <style>\n    main { max-width: 36rem; margin: 2rem auto; padding: 0 1rem; }\n    a:focus-visible { outline: 3px solid #333; }\n  </style>\n</head>\n<body>\n  <main>\n    <h1>Mijn proefpagina</h1>\n    <p>Welkom bij mijn eerste project.</p>\n    <a href="mailto:voorbeeld@example.com">Contact</a>\n  </main>\n</body>\n</html>'
extras={
'ai-werkdag':('Een uitgewerkt promptvoorbeeld','U maakt een intern actieoverzicht voor drie lezers. Gebruik uitsluitend de tekst onder Bron. Geef één regel per actie met een verantwoordelijke en datum. Schrijf ‘onbekend’ wanneer een van beide ontbreekt. Zet losse ideeën onder ‘Ter bespreking’. Bron: Team A bevestigt de presentatie op dinsdag. Team B verstuurt de locatie later. Iemand stelde een enquête voor. Verwacht: presentatie, Team A, dinsdag; locatie versturen, Team B, onbekend; enquête staat ter bespreking.'),
'promptbibliotheek-gids':('Voorbeeld van een catalogusrecord','Naam: productbeschrijving op feiten. Eigenaar: redacteur. Invoer: materiaal, afmetingen en vier gecontroleerde kenmerken. Uitvoer: één titel, twee beschrijvende zinnen en een regel met ontbrekende gegevens. Uitsluiting: geen schatting van een gewicht. Testversie 1 faalt omdat ‘licht’ bij gebrek aan gewicht werd ingevuld. In versie 2 wordt elk gewichtswoord zonder bron als ontbrekend gemarkeerd.'),
'ai-antwoorden-checken':('Een mini-audit','Een antwoord noemt ‘60 procent van 85 klanten’. Narekenen geeft 51 klanten, maar een geraadpleegde tabel geeft 51 reacties op 85 uitnodigingen. Dat is een responspercentage, geen waarderingscijfer. Vervang de claim door ‘51 van de 85 genodigden reageerden’ en vermeld de periode. Dezelfde berekening krijgt zo een correcte betekenis.'),
'ai-voor-klantenservice':('Voorbeeldantwoord met overdracht','Een klant meldt een afschrijving die hij niet herkent. Vraag in de automatische tekst wanneer de afschrijving plaatsvond en verwijs naar het beveiligde kanaal van de winkel. Laat een medewerker de betaalreferentie controleren. Deel geen rekeningnummer, persoonsgegevens of veronderstelde oorzaak vanuit het AI-antwoord.'),
'ai-leergids':('Weekroute','Dag 1: maak mappen. Dag 2: maak kopieën en herken de definitieve versie. Dag 3: vul een tabel. Dag 4: controleer twee uitkomsten handmatig. Dag 5: zoek een oorspronkelijke bron. Dag 6: vergelijk een AI-bewerking met uw eigen tekst. Dag 7: lever het projectoverzicht op en laat iemand één bestand terugvinden.'),
'prijzen-proef':('Twee pakketten vergelijken','Gebruik fictieve bedragen. Eén opname met korte montage vergt 10 uur. Met € 45 per uur als rekenbedrag en € 60 aan directe projectkosten is de som € 510. Een tweede export in een ander formaat met twee uur nabewerking geeft € 90 extra rekenruimte. De prijskeuze bespreekt u los van de uitkomst van dit oefenvoorbeeld.'),
'eerste-freelanceklant':('Een eerste bericht','Geachte mevrouw De Vries, ik maak portretten voor kleine zorgpraktijken. Bij uw teampagina zag ik dat enkele collega’s al een foto hebben. Ik kan tijdens één rustig ochtendblok een consistente reeks maken, inclusief bestanden voor uw website. Zou een korte kennismaking op dinsdag of donderdag u passen? Met vriendelijke groet, [naam].'),
'budget-van-nul':('Een fout in het oefenbudget','Dezelfde betaling van € 24 komt voor op de creditcard en op het bankafschrift. Het bankafschrift toont de aflossing van die card, niet dezelfde aankoop opnieuw. Houd aankoop en verrekening zichtbaar en bepaal welke mutatie in uw uitgavenrubriek thuishoort. Het budget moet aansluiten op de periode die u werkelijk vergelijkt.'),
'spaardoelen-gids':('Een nieuwe stand doorrekenen','Na twee maanden staat het saldo op € 210 en zijn er nog zes maanden over. Voor een doel van € 600 resteert € 390. Deel dit bedrag door zes: € 65 per maand. Vergelijk dat met de eerdere € 60 en noteer waarom de benodigde bijdrage verandert.'),
'beleggen-in-begrippen':('Oefening met kosten','Fonds A vermeldt fictief 0,20% doorlopende kosten per jaar en fonds B 0,60%. Bij een ongewijzigde rekenstand van € 1.000 zijn dit € 2 en € 6. Dit eenvoudige voorbeeld laat transactiekosten, koersverandering en belastingen buiten beschouwing. Beoordeel echte kosten aan de hand van het actuele informatiedocument.'),
'focusdag-gids':('Een ingevulde dag','09.00–09.15 uitkomst kiezen. 09.15–10.00 voorstel uitwerken. 10.00–10.15 korte berichten. 10.15–11.00 cijfers controleren. 11.00–11.30 onderbrekingen of herstelwerk. Neem om 11.30 een besluit over wat klaar is om te delen.'),
'adhd-vriendelijke-werkdag':('Twee verschillende terugkeerzinnen','Bij een leesopdracht schrijft u vóór de pauze: ‘Open pagina 14 en markeer het eerste argument’. Bij een werkblad schrijft u: ‘Voeg de drie ontbrekende cijfers uit versie B toe’. Beide zinnen beschrijven een handeling en de plek waar die begint.'),
'weekmenu-vlot':('Vijf dagen als voorbeeld','Maandag: brood met bonensalade. Dinsdag: tomaten-linzensoep. Woensdag: aardappel met geroosterde groenten. Donderdag: tortilla met bonen en paprika. Vrijdag: pasta met tomaat. Dit is een menuvoorbeeld; kies hoeveelheden en ingrediënten die bij uw huishouden passen.'),
'maaltijdvoorbereiding':('Een voorbeeldvolgorde','Zet ingrediënten klaar, kies eerst de langste kookhandeling en bereid de koude componenten op een schoon werkvlak. Noteer op de bakjes datum en inhoud. Bereid een later gerecht desgewenst met onbewerkte voorraad in plaats van restjes lang in de koelkast te laten staan.'),
'fotografie-product':('Een lichtproef zonder technische instellingen','Plaats het product op een vel papier met het raam aan de linkerzijde. Maak één foto, draai het oppervlak een kwartslag en maak een tweede. Kijk waar lichte letters leesbaar blijven zonder dat schaduwen verdwijnen. Gebruik bijvoorbeeld een wit kartonnetje om een diepe schaduw aan de overzijde te verzachten.'),
'video-editing':('Een tijdlijn van 30 seconden','0–4 seconden: open met het resultaat. 4–13 seconden: toon de beginsituatie en één korte handeling. 13–23 seconden: laat zien wat verandert. 23–30 seconden: toon een leesbare afsluitende instructie. Deze verdeling is een oefenvoorbeeld; beoordeel de werkelijke export met een kijker.'),
'bruiloft-route':('Een voorbeeldregel in het draaiboek','14.00 ontvangst aan de entree, begeleid door de ceremoniemeester. 14.20 gasten begeleiden naar de zaal. 14.30 start ceremonie. Bij regen wacht de aangewezen gastheer binnen, met een papieren plattegrond voor laatkomers.'),
'cursus-webpagina':('Voorbeeldcode voor de werkopdracht',html_example)
}
for line in (here/'extras.txt').read_text().splitlines():
    sku, heading, body = line.split('|')
    extras[sku]=(heading,body)
def row(kind,genre,sku,title,price,summary):
    return dict(kind=kind,category=genre,sku=sku,title=title,price=price,summary=summary,sections=[])

def inputs():
    for line in (here/'guides.txt').read_text().splitlines():
        genre,sku,title,price,summary,case,*chapters=line.split('|')
        m=row('ebook',genre,sku,title,price,summary)
        m['sections'].append(('Het uitgangspunt',[case,summary]))
        for chapter in chapters:
            heading,body=chapter.split('~')
            m['sections'].append((heading,[body]))
        if sku in extras: m['sections'].append((extras[sku][0],[extras[sku][1]]))
        m['sections'].append(('Zelf toepassen', [
            'Gebruik de casus uit de inleiding als proef. Kies eerst welke gegevens u al heeft, wat nog ontbreekt en welke bron u daarvoor mag raadplegen. Bewaar uw eerste uitwerking, zodat u die aan het eind met uw verbeterde versie kunt vergelijken.',
            'Voer nu de handeling uit bij ‘'+m['sections'][1][0]+'’. Loop vervolgens de overige hoofdstukken in volgorde langs. Schrijf als slot in één zin op wat u heeft gewijzigd en wat een ander nodig heeft om het resultaat te controleren.',
            'Kies een kleine verandering in uw eigen situatie en pas uw uitwerking opnieuw toe. Kijk of daarmee een aanname in de oorspronkelijke casus verandert en waarom. Gebruik de uitkomst om uw volgende stap concreet te beschrijven.'
        ]))
        yield m
    for line in (here/'courses.txt').read_text().splitlines():
        genre,sku,title,price,summary,minutes,case,*chapters=line.split('|')
        m=row('course',genre,sku,title,price,summary)
        m['minutes']=int(minutes)
        m['sections'].append(('Uw eindresultaat',[summary,case,'Benodigdheden: een computer of tablet, een plek om uw werk te bewaren en de hulpmiddelen die bij uw gekozen opdracht passen. Maak eerst een map voor concepten en een aparte map voor het eindresultaat.']))
        duration=int(minutes)
        for index, chapter in enumerate(chapters,1):
            heading,body,deliver=chapter.split('~')
            target=(duration//3 if index<3 else duration-2*(duration//3))
            m['sections'].append((f'Les {index} · {heading}',[f'Oefentijd: ongeveer {target} minuten.',body,'Opdracht: '+deliver]))
        if sku in extras: m['sections'].append((extras[sku][0],[extras[sku][1]]))
        m['sections'].append(('Afronding en zelfbeoordeling',[
            'Leg de drie uitwerkingen naast elkaar. Controleer ze aan de hand van deze opleverpunten:',
            *[chapter.split('~')[-1] for chapter in chapters],
            'Wijs één keuze aan die u kunt uitleggen met een feit uit de oefensituatie. Controleer ook of een lezer met het eindresultaat kan beginnen zonder uw lesmateriaal erbij. Herstel het eerste punt waarop u dat niet kunt aantonen en bewaar de herziene versie.'
        ]))
        yield m
    for line in (here/'templates.txt').read_text().splitlines():
        genre,sku,title,price,summary,instructions,headers,*values=line.split('|')
        m=row('template',genre,sku,title,price,summary)
        if sku=='canva-ontwerpbrief':
            m['title']='Drie socialmedia-sjablonen voor Canva'
            m['summary']='Bewerk drie socialmedia-ontwerpen voor een aankondiging, agenda en uitgelichte titel.'
            m['sections']=[
                ('Het ontwerp openen',['Importeer het PowerPoint-bestand in Canva of open het in PowerPoint. De dia’s bestaan uit losse tekstvakken en vormen. Controleer na import de gebruikte lettertypen en regelafbrekingen.']),
                ('Drie verschillende toepassingen',['Gebruik dia 1 voor een aankondiging met datum, dia 2 voor een programma en dia 3 voor een uitgelichte titel. Vervang voorlopige gegevens en afbeeldingen vóór publicatie.']),
                ('Klaarmaken voor publicatie',['Bekijk de leesbaarheid op telefoonformaat, controleer beeldrechten en exporteer alleen de gewenste dia. Maak een beschrijvende alt-tekst voordat u publiceert.'])
            ]
            yield m
            continue
        m['headers']=headers.split(';')
        m['samples']=[value.split(';') for value in values]
        m['sections']=[
            ('In gebruik nemen',[summary,instructions,'Open het tabblad Invoer. Vul eerst één echte regel in een kopie van het bestand in. Een ingevuld fictief voorbeeld staat apart op het tabblad Voorbeeld.']),
            ('De kolommen begrijpen',[', '.join(m['headers'])+'.', 'Gebruik tabblad Invoer voor uw eigen gegevens. Laat formulecellen indien aanwezig ongemoeid. Bekijk het voorbeeld om te bepalen welke gegevens u per veld nodig heeft.']),
            ('Controle en afronding',['Vergelijk uw eerste gegevens met de oorspronkelijke bron. Controleer of datums en eenheden consequent zijn. Bewaar vervolgens een eigen versie met periode of datum in de bestandsnaam.'])
        ]
        if sku=='freelance-dashboard':
            m['title']='Notion-startpakket voor freelancers'
            m['summary']='Richt een Notion-werkruimte in met een dashboard, importeerbare pipelines en een PDF-handleiding.'
            m['sections']=[
                ('Bestanden importeren',['Pak het ZIP-bestand uit. Importeer Start-dashboard.md via Tekst en Markdown in Notion. Importeer Klanten.csv, Projecten.csv en Acties.csv elk als aparte database.']),
                ('De weergaven instellen',['Maak voor Projecten een bordweergave gegroepeerd op Status. Sorteer Acties op Deadline. Maak vanuit het dashboard links naar alle drie databases. Zet voorbeeldregels pas weg nadat de inrichting klopt.']),
                ('Proeftraject uitvoeren',['Maak één fictieve klant aan en voeg een project en eerste actie toe. Controleer of de actie op de verwachte plek verschijnt en of een andere gebruiker de relatie met het project begrijpt.'])
            ]
        yield m
    for name in ('stories.txt','recipes.txt'):
        for text in (here/name).read_text().strip().split('\n===\n'):
            header,*children=text.strip().split('\n## ')
            genre,sku,title,price,summary=header.strip().split('|')
            m=row('ebook',genre,sku,title,price,summary)
            m['story']=name=='stories.txt'
            m['recipe']=name=='recipes.txt'
            for child in children:
                heading,content=child.split('\n',1)
                m['sections'].append((heading,[line.strip() for line in content.splitlines() if line.strip()]))
            yield m

def ps(name,font,size,lead,**kwargs):
    return ParagraphStyle(name,fontName=font,fontSize=size,leading=lead,textColor=HexColor('#201f1c'),**kwargs)
styles={
 'title':ps('Title','LuccoSerif',29,36,spaceAfter=19),
 'summary':ps('Summary','LuccoSans',10.7,17,spaceAfter=15),
 'heading':ps('Heading','LuccoSerif',19,24,spaceBefore=17,spaceAfter=9,keepWithNext=True),
 'body':ps('Body','LuccoSans',9.8,16,spaceAfter=12),
 'story':ps('Story','LuccoSerif',10.8,17,spaceAfter=12),
 'small':ps('Small','LuccoBold',8,12,spaceAfter=14),
 'code':ps('Code','Courier',6.6,9,spaceAfter=8)
}
def create_pdf(m, path):
    label, ink, _ = genres[m['category']]
    def text(paragraph,style):
        return Paragraph(escape(paragraph).replace('\n','<br/>'),styles[style])
    def decorate(canvas,doc):
        canvas.setFillColor(HexColor('#fdfbf7'))
        canvas.rect(0,0,*A5,fill=1,stroke=0)
        canvas.setFillColor(HexColor(ink))
        canvas.rect(0,A5[1]-9,A5[0],9,fill=1,stroke=0)
        canvas.setFont('LuccoSans',7.5)
        canvas.drawString(33,22,'LUCCO')
        canvas.drawRightString(A5[0]-33,22,str(doc.page))
    items=[Spacer(1,55),text(label.upper(),'small'),text(m['title'],'title'),text(m['summary'],'summary')]
    if m['kind']=='course': items.append(text(f"Zelfstudie · {m['minutes']} minuten · drie lessen",'small'))
    elif m.get('story'): items.append(text('Kort verhaal · Nederlandse uitgave','small'))
    if not m.get('story'):
        items += [text('Inhoud','heading')]
        items += [text(heading,'body') for heading,_ in m['sections']]
    items.append(PageBreak())
    paragraph_style='story' if m.get('story') else 'body'
    for index,(heading,paragraphs) in enumerate(m['sections']):
        if index and (m.get('story') or m.get('recipe') or m['kind']=='course'):
            items.append(PageBreak())
        items.append(text(heading,'heading'))
        for p in paragraphs:
            if p.startswith('<!doctype html>'):
                items.append(Preformatted(p,styles['code'],maxLineLength=75))
            else:
                items.append(text(p,paragraph_style))
    if m['sku'] in sources:
        title,url=sources[m['sku']]
        items.append(text('Bron','heading'))
        items.append(Paragraph(f'<a href="{escape(url)}" color="#353e3b">{escape(title)}</a>',styles['body']))
    SimpleDocTemplate(str(path),pagesize=A5,topMargin=32,bottomMargin=40,leftMargin=33,rightMargin=33,
        title=m['title'],author='LUCCO').build(items,onFirstPage=decorate,onLaterPages=decorate)

def create_epub(m,path):
    chapters=m['sections'].copy()
    if m['sku'] in sources: chapters.append(('Bron',[sources[m['sku']][0],sources[m['sku']][1]]))
    names=[f'chapter-{i+1}.xhtml' for i in range(len(chapters))]
    def wrap(title,content):
        return '<?xml version="1.0" encoding="utf-8"?><html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" lang="nl" xml:lang="nl"><head><title>'+x(title)+'</title><link rel="stylesheet" type="text/css" href="book.css"/></head><body>'+content+'</body></html>'
    toc=''.join(f'<li><a href="{name}">{x(chapter[0])}</a></li>' for name,chapter in zip(names,chapters))
    manifest=''.join(f'<item id="s{i}" href="{name}" media-type="application/xhtml+xml"/>' for i,name in enumerate(names))
    spine=''.join(f'<itemref idref="s{i}"/>' for i in range(len(names)))
    with ZipFile(path,'w',ZIP_DEFLATED) as f:
        f.writestr('mimetype','application/epub+zip',compress_type=ZIP_STORED)
        f.writestr('META-INF/container.xml','<?xml version="1.0"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="EPUB/book.opf" media-type="application/oebps-package+xml"/></rootfiles></container>')
        f.writestr('EPUB/book.css','body{font-family:serif;line-height:1.5} h1{margin-top:1.25em} pre{white-space:pre-wrap}')
        f.writestr('EPUB/nav.xhtml',wrap(m['title'],f'<h1>{x(m["title"])}</h1><p>{x(m["summary"])}</p><nav epub:type="toc"><h2>Inhoud</h2><ol>{toc}</ol></nav>'))
        f.writestr('EPUB/book.opf',f'<?xml version="1.0" encoding="utf-8"?><package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="bookid"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:identifier id="bookid">urn:lucco:{m["sku"]}:1</dc:identifier><dc:title>{x(m["title"])}</dc:title><dc:language>nl</dc:language><dc:creator>LUCCO</dc:creator><meta property="dcterms:modified">2026-11-27T00:00:00Z</meta></metadata><manifest><item id="toc" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/><item id="style" href="book.css" media-type="text/css"/>{manifest}</manifest><spine><itemref idref="toc"/>{spine}</spine></package>')
        for name,(heading,ps) in zip(names,chapters):
            content=f'<h1>{x(heading)}</h1>'
            for paragraph in ps:
                if paragraph.startswith('<!doctype html>'): content+='<pre>'+x(paragraph)+'</pre>'
                elif paragraph.startswith('https://'): content+=f'<p><a href="{x(paragraph)}">{x(paragraph)}</a></p>'
                else: content+='<p>'+x(paragraph)+'</p>'
            f.writestr('EPUB/'+name,wrap(heading,content))

special={'maandbudget-sheet':('F','=IF(COUNT(D@,E@)=2,E@-D@,"")'), 'spaardoelen-sheet':('E','=IF(AND(COUNT(B@,C@,D@)=3,D@>0),MAX(0,B@-C@)/D@,"")')}
def create_workbook(m,path):
    book=Workbook()
    intro=book.active
    intro.title='Begin hier'
    intro.append([m['title']])
    for heading, paragraphs in m['sections']:
        intro.append([heading])
        for p in paragraphs: intro.append([p])
    intro.column_dimensions['A'].width=94
    for cell in intro['A']:
        cell.alignment=Alignment(wrap_text=True,vertical='center')
        intro.row_dimensions[cell.row].height=38 if len(str(cell.value or ''))>85 else 23
    for tab in ('Invoer','Voorbeeld'):
        sheet=book.create_sheet(tab)
        sheet.append(m['headers'])
        if tab=='Voorbeeld':
            for sample in m['samples']: sheet.append([float(v) if re.fullmatch(r'\d+(\.\d+)?',v) else v for v in sample])
        if m['sku'] in special:
            column,formula=special[m['sku']]
            for i in range(2,32 if tab=='Invoer' else 2+len(m['samples'])):
                sheet[f'{column}{i}']=formula.replace('@',str(i))
                sheet[f'{column}{i}'].number_format='0.00'
        if m['sku']=='maandbudget-sheet':
            sheet['A34']='Netto gepland'
            sheet['B34']='=SUMIF(A2:A31,"Inkomst",D2:D31)-SUMIF(A2:A31,"Uitgave",D2:D31)'
            sheet['A35']='Netto werkelijk'
            sheet['B35']='=SUMIF(A2:A31,"Inkomst",E2:E31)-SUMIF(A2:A31,"Uitgave",E2:E31)'
        for idx,column in enumerate(m['headers'],1):
            cell=sheet.cell(1,idx); cell.fill=PatternFill('solid',fgColor='4C4540'); cell.font=Font(color='FFFFFF',bold=True)
            sheet.column_dimensions[get_column_letter(idx)].width=max(19,min(36,len(column)+5))
        sheet.freeze_panes='A2'
        sheet.auto_filter.ref=f'A1:{get_column_letter(len(m["headers"]))}31'
    book.save(path)

def product_cover(m,target):
    label,ink,palette=genres[m['category']]
    full=Image.new('RGBA',(650,700),'#eeebe6')
    ground=Image.new('RGBA',full.size)
    d=ImageDraw.Draw(ground)
    d.ellipse((-90,-180,540,430),fill='#fffdf9')
    d.ellipse((305,360,1050,980),fill=palette)
    full=Image.alpha_composite(full,ground.filter(ImageFilter.GaussianBlur(94)))
    w,h=340,491
    book=Image.new('RGBA',(w,h),ink); draw=ImageDraw.Draw(book)
    chapter_font=ImageFont.truetype(str(fonts/'DejaVuSans.ttf'),14)
    display_font=ImageFont.truetype(str(fonts/'DejaVuSerif.ttf'),44)
    draw.rectangle((11,11,w-12,h-12),outline=palette,width=1)
    draw.line((27,28,27,h-29),fill=palette,width=1)
    draw.text((46,43),'LUCCO',font=chapter_font,fill='#f9f6ef')
    lines=[]; value=''
    for word in m['title'].split():
        candidate=(value+' '+word).strip()
        if value and draw.textlength(candidate,font=display_font)>w-91:
            lines.append(value); value=word
        else: value=candidate
    if value: lines.append(value)
    widest=max(draw.textlength(v,font=display_font) for v in lines)
    if widest>w-91: display_font=ImageFont.truetype(str(fonts/'DejaVuSerif.ttf'),int(44*(w-91)/widest))
    if m['category'] in ('thriller','romantiek'):
        draw.ellipse((192,65,296,173),outline=palette,width=2)
        draw.line((143,121,304,121),fill=palette,width=2)
    else:
        n=sum(map(ord,m['sku']))%4
        for j in range(3+n):
            xx=142+j*19
            draw.arc((xx,70,xx+76,152),210,332,fill=palette,width=2)
    for j,line in enumerate(lines): draw.text((45,179+j*48),line,font=display_font,fill='#fffaf2')
    draw.text((45,h-59),kinds[m['kind']].upper(),font=chapter_font,fill='#f7efe2')
    angle=(sum(map(ord,m['sku']))%13)-6
    book=book.rotate(angle,expand=True,resample=Image.Resampling.BICUBIC)
    xx=(650-book.width)//2; yy=(700-book.height)//2-12
    shadow=Image.new('RGBA',full.size)
    shadow.paste('#201c1b',(xx+18,yy+26,xx+18+book.width,yy+26+book.height),book.getchannel('A').point(lambda a:a//3))
    full=Image.alpha_composite(full,shadow.filter(ImageFilter.GaussianBlur(22)))
    full.alpha_composite(book,(xx,yy))
    full.convert('RGB').save(target,'WEBP',quality=86,method=6)

def canva_deck(path):
    r=Presentation()
    r.slide_width=Inches(8)
    r.slide_height=Inches(8)
    slides=[
        ('AANKONDIGING','Een nieuwe uitgave','Uw korte toelichting komt hier.','Bekijk de uitgave', 'EDE6DA','352F2B'),
        ('PROGRAMMA','Een middag in de studio','14.00 Ontvangst\n14.30 Presentatie\n15.15 Vragen','Reserveer uw plek','D5D9CB','293B32'),
        ('UITGELICHT','Een titel om te ontdekken','Voeg hier de belangrijkste reden toe om dit boek te lezen.','Lees het fragment','DAC3B8','4D3030'),
    ]
    for over,title,detail,action,bg,fg in slides:
        slide=r.slides.add_slide(r.slide_layouts[6])
        fill=slide.background.fill
        fill.solid()
        fill.fore_color.rgb=RGBColor.from_string(bg)
        border=slide.shapes.add_shape(MSO_SHAPE.RECTANGLE,Inches(.42),Inches(.42),Inches(7.16),Inches(7.16))
        border.fill.background()
        border.line.color.rgb=RGBColor.from_string(fg)
        for value,y,size in [(over,1.02,13),(title,1.88,44),(detail,4.31,19),(action,6.35,16)]:
            box=slide.shapes.add_textbox(Inches(.85),Inches(y),Inches(6.25),Inches(1.9 if size==44 else 1.4))
            box.text_frame.word_wrap=True
            for index,line in enumerate(value.split('\n')):
                p=box.text_frame.paragraphs[0] if index==0 else box.text_frame.add_paragraph()
                p.text=line
                p.font.name='Georgia' if size==44 else 'Arial'
                p.font.size=Pt(size)
                p.font.color.rgb=RGBColor.from_string(fg)
    r.save(path)

def notion_kit(path):
    data = {
        'Klanten.csv':('Klant;Contact;Dienst;Status','Voorbeeldklant;Referentie A;Portretfotografie;Intake'),
        'Projecten.csv':('Project;Klant;Oplevering;Status','Project A;Voorbeeldklant;Zes portretten;Open'),
        'Acties.csv':('Actie;Project;Deadline;Status','Briefing versturen;Project A;2026-12-08;Gepland'),
    }
    with ZipFile(path,'w',ZIP_DEFLATED) as f:
        f.writestr('Start-dashboard.md','# Freelancedashboard\n\n## Klanten\nVoeg hier de link naar Klanten toe.\n\n## Actieve projecten\nLink naar uw Projecten-bord en filter afgeronde projecten.\n\n## Eerstvolgende acties\nLink naar Acties en sorteer op deadline.\n\n## Weekafsluiting\nControleer vrijdag alle openstaande afspraken en volgende acties.\n')
        for name, rows in data.items():
            buffer=io.StringIO()
            csv.writer(buffer).writerows(r.split(';') for r in rows)
            f.writestr(name,buffer.getvalue())

def preview(pdf,path):
    with TemporaryDirectory() as tmp:
        dest=Path(tmp)/'preview'
        subprocess.run(['pdftoppm','-f','2','-l','2','-scale-to','950','-singlefile','-png',str(pdf),str(dest)],check=True,capture_output=True)
        with Image.open(dest.with_suffix('.png')) as image: image.convert('RGB').save(path,'WEBP',quality=84,method=6)

catalog=[]
for m in inputs():
    sku=m['sku']
    filebase=sku+'-v1'
    pdf=files/(filebase+'.pdf')
    create_pdf(m,pdf)
    pages=len(PdfReader(pdf).pages)
    preview(pdf,media/(sku+'-fragment.webp'))
    product_cover(m,media/(sku+'-omslag.webp'))
    other=None
    if sku in ('canva-ontwerpbrief','freelance-dashboard'):
        main=filebase+('.pptx' if sku=='canva-ontwerpbrief' else '.zip')
        (canva_deck if sku=='canva-ontwerpbrief' else notion_kit)(files/main)
        other=pdf.name
        fmt=('PPTX met drie ontwerpen' if sku=='canva-ontwerpbrief' else 'ZIP met Markdown en CSV')+' + PDF-handleiding'
        compat='Canva-import of PowerPoint' if sku=='canva-ontwerpbrief' else 'Notion-import'
    elif m['kind']=='template':
        other=filebase+'.xlsx'
        create_workbook(m,files/other)
        main=other
        other=pdf.name
        fmt='XLSX + PDF-handleiding'
        compat='Excel of een toepassing die XLSX ondersteunt'
    elif m['kind']=='course':
        main=pdf.name
        fmt=f'PDF-lespakket · {pages} pagina’s'
        compat='PDF-lezer'
    else:
        main=pdf.name
        other=filebase+'.epub'
        create_epub(m,files/other)
        fmt=f'PDF ({pages} pagina’s) + EPUB'
        compat='PDF-lezer of een toepassing die EPUB ondersteunt'
    group=kinds[m['kind']]
    chapters=[title for title,_ in m['sections']]
    adjectives={'ebook':'De uitgave is volledig Nederlandstalig en bevat de volgende onderdelen.',
        'template':'U ontvangt een bewerkbaar Excel-bestand en een korte PDF-handleiding. De voorbeeldgegevens staan in een apart werkblad.',
        'course':f'U doorloopt drie lessen in eigen tempo. Trek ongeveer {m.get("minutes","")} minuten uit voor lezen, oefenen en zelfbeoordeling.'}
    description=m['summary']+' '+adjectives[m['kind']]
    if sku in ('canva-ontwerpbrief','freelance-dashboard'): description=m['summary']+' Inclusief een handleiding voor het openen en aanpassen.'
    if m.get('story'): description=m['summary']+' Een oorspronkelijk Nederlands kort verhaal met vier hoofdstukken en een afgeronde ontknoping.'
    catalog.append(dict(sku=sku,title=m['title'],summary=m['summary'],description=description,price=m['price'],
        kind=m['kind'],category=m['category'],format=fmt,language='Nederlands',version='1.0',compatibility=compat,
        image_url=f'/media/{sku}-omslag.webp',image_alt=f'Omslag van {m["title"]}',
        preview_url=f'/media/{sku}-fragment.webp',includes=chapters,minutes=m.get('minutes'),file='lucco-bibliotheek/'+main,
        **({'alternative_file':'lucco-bibliotheek/'+other} if other else {})))
# A representative mix of the catalog appears first, with filters for the full range.
featured=['de-lamp-in-het-archief','ai-werkdag','licht-op-zondagochtend','maandbudget-sheet','eerste-freelanceklant','cursus-ai-mail','peulvruchten-aan-tafel','focusplanner-sheet','cursus-foto','bruiloft-sheet','cursus-webpagina','studieweek']
by_id={p['sku']:p for p in catalog}
catalog=[by_id[key] for key in featured]+[p for p in catalog if p['sku'] not in featured]
(root/'catalog-books.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n')
print(len(catalog),{key:sum(p['kind']==key for p in catalog) for key in kinds})
