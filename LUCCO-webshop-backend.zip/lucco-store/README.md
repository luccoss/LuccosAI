# LUCCO-webshop

Een webshop voor digitale downloads met een Engelstalige catalogus, gastcheckout, Mollie, facturen, orderbevestiging en ordergebonden downloads. De bestaande LUCCO-vormgeving is gebruikt als basis. De implementatie gebruikt Node.js en SQLite. De betaal- en mailaanbieders zijn Mollie en Resend. De eerste verkoopopzet rekent in euro af met Nederland als factuurland. Stel de juiste btw per SKU in vóór publicatie.

## Lokaal openen

1. Pak de ZIP uit en open de map `lucco-store` in een terminal met Node.js 24 of hoger.
2. Voer `npm start` uit en open [de demo](http://127.0.0.1:3000).
3. Voeg een artikel toe, kies **Verder naar afrekenen** en gebruik fictieve factuurgegevens. Klik in de betaalsimulatie op **Geslaagd**, **Mislukt** of **Geannuleerd**. Via de betaalpagina kun je een betaalde demo-order ook als terugbetaald markeren.
4. Na een geslaagde simulatie kun je de testfactuur en testdownload openen. De app schrijft de bevestiging naar `data-demo/test-email-<nummer>.txt`.
5. Voer `npm test` uit voor de integratietests.

De demo bevat 7 Engelse PDF-e-books. Elke productpagina heeft een omslag en een voorbeeld uit het PDF-bestand. Bij het bijwerken van de demo verdwijnen de eerder aangeboden templates, mini-cursussen en oudere e-books uit het assortiment. Bestaande bestellingen behouden hun ordergegevens. Nieuwe test- en live-omgevingen starten met een lege catalogus. Elke omgeving heeft een eigen SQLite-database.

## Bijwerken op Railway

De publicatie-instructie `publicatie.md` in de hoofdmap van het archief bevat de stappen voor de volledige release.

Vervang in dezelfde GitHub-repository het bestaande bestand `LUCCO-webshop-backend.zip` door dit bestand met dezelfde naam. Dit archief bewaart de map `lucco-store`, zodat het eerdere Dockerfile dezelfde bronbestanden kan uitpakken. Commit de upload op de branch die Railway volgt. Wacht op **Deployment successful** en open de bestaande Railway-link. Het assortiment wordt automatisch in een omgeving met `LUCCO_MODE=demo` geladen. Gebruik voor deze openbare demo fictieve factuurgegevens bij het testen. Het instellen van echte betalingen vergt de afzonderlijke stappen hieronder.

## Catalogus vullen

Voor een nieuwe test- of livecatalogus importeert `node admin.mjs import-edition` de LUCCO-artikelen als concepten en kopieert de digitale bestanden naar de privémap. Controleer de licentietekst, vul het juiste btw-tarief en de beoordelaar in voordat u een artikel publiceert.

Gebruik `catalog-template.csv` voor een leveranciersfeed met puntkomma’s. Gebruik een stabiele SKU per leverbare licentie, bijvoorbeeld één SKU voor gebruik en één SKU voor doorverkoop. Vul titel, korte samenvatting, volledige productomschrijving, inhoud, formaat, compatibiliteit, taal, versie, totaalprijs inclusief btw en btw-tarief in. Noteer de licentie voor de klant en bij een resellerlicentie de exacte rechten en beperkingen. `rights_ref` en `image_rights_ref` verwijzen naar jouw interne bewijsstukken. `reviewed_by` legt vast wie de gegevens en rechten heeft gecontroleerd.

1. Plaats ieder echt downloadbestand in `LUCCO_DATA/files/` onder een unieke naam per versie. Zet in `file` het relatieve bestandspad. Bewaar oudere bestanden waarmee orders zijn geleverd.
2. Gebruik goedgekeurde productfoto’s of covers met een HTTPS-URL en een beschrijvende alt-tekst. Bewaar de rechtenregistratie bij de catalogus. Houd eventuele leverancierstoegang en downloadbestanden privé.
3. Stel de omgeving in en voer `./import-feed.sh leveranciersfeed.csv` uit. Dat bewaart de bronfeed en importeert concepten. Het kan ook in twee stappen met `python3 import_csv.py leveranciersfeed.csv concepten.json` en `node admin.mjs import concepten.json`.
4. Gebruik `node admin.mjs catalog` om SKU’s te bekijken. Publiceer gecontroleerde items met `node admin.mjs publish SKU1 SKU2`. Voor `discount_from` vul je alleen een referentieprijs in die je kunt onderbouwen.
5. Gebruik `node admin.mjs unpublish SKU1` om nieuwe verkoop van dat artikel stop te zetten. Opnieuw importeren vernieuwt de concepten. Publiceer een gecontroleerde prijs- of productupdate opnieuw om die aan klanten te tonen.

Deze import is een aansluiting voor aangeleverde CSV-bestanden. Een leveranciersspecifieke API-koppeling, live voorraad- en prijsupdates, automatische orderdoorzetting en synchronisatie van afbeeldingen zijn nog niet geïmplementeerd. De huidige versie levert digitale bestanden die LUCCO zelf beheert. Een leveranciersfeed met ontbrekende gegevens blijft in concept tot de artikelinformatie, bestanden en rechten zijn aangevuld.

## Staging en productie

Zet de app op Node.js-hosting die langdurig kan draaien, een eigen HTTPS-domein gebruikt en een schrijfbare, blijvende schijf biedt. Gebruik per omgeving één actieve app-instantie met een eigen SQLite-bestand. Voor statische of alleen PHP-hosting is een Node.js-hostingoptie nodig. Plaats de app achter de HTTPS-proxy van je hosting. Houd de data- en configuratiebestanden buiten de publieke sitefolder.

- Kopieer `.env.example` naar `.env`, vul de waarden privé in en start met `node --env-file=.env server.mjs`. Gebruik `node --env-file=.env admin.mjs catalog` voor beheer met dezelfde instellingen. Kies een willekeurige `LUCCO_SECRET` en bewaar de waarde bij de omgevingsconfiguratie.
- Start met `LUCCO_MODE=test`, een afzonderlijke datamap, een Mollie-test-API-sleutel en een publiek bereikbare HTTPS-webhook op `/webhooks/mollie`. De webapp gebruikt de status die Mollie zelf teruggeeft. Beperk desgewenst toegang tot de rest van staging via je HTTPS-proxy. Test iDEAL en kaart voor zover beschikbaar op jouw Mollie-profiel, inclusief betaling, mislukking, annulering, opnieuw laden, terugbetalingen en het werkelijk ontvangen van de bevestiging. [Mollie over testmodus](https://docs.mollie.com/reference/testing) · [Mollie over betaalwebhooks](https://docs.mollie.com/reference/webhooks)
- Verifieer het afzenderdomein bij Resend. Stel `RESEND_API_KEY` en `MAIL_FROM` in. In productie geeft de app downloads vrij nadat Resend de koopbevestiging heeft geaccepteerd. Het is belangrijk ontvangst en eventuele bounces in het echte mailaccount te controleren.
- Vul voor live de bedrijfsnaam, het vestigingsadres, KVK-nummer, btw-identificatienummer en contactmail in. Configureer de definitieve privacyverklaring, voorwaarden en pagina over levering en herroeping met de bijbehorende URL’s. Bekijk de factuur en voorlichting met echte winkelgegevens. De factuur is een afdrukbare HTML-pagina. De app registreert de akkoordverklaring voor directe digitale levering en biedt **Koop ongedaan maken** op de winkel- en bestelpagina’s. [ACM over bedenktijd en herroepen](https://www.acm.nl/nl/verkoop-aan-consumenten/klantenservice/bedenktijd) · [Belastingdienst over factuureisen](https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/btw/administratie_bijhouden/facturen_maken/factuureisen/)
- Zet productie op `LUCCO_MODE=live` met een aparte datamap, live Mollie-sleutel, definitief domein en goedgekeurde producten. Verifieer `/robots.txt`, `/sitemap.xml` en de canonieke product-URL’s. Demo en staging geven een noindex-header en blokkeren crawlers via robots.txt. Privépagina’s, API’s en checkout zijn ook in productie uitgesloten van indexatie.
- Regel back-ups van SQLite en de bestanden, toegang voor beheer, automatische herstart, HTTPS en bescherming tegen hoge verkeerspieken. Gebruik bij SQLite een consistente back-up via de SQLite back-upfunctie. Test herstel op een aparte locatie. Houd wachtwoorden en API-sleutels in het hostingpaneel. Laat je proxy bestel-URL’s met privétokens uit openbare logs houden.

## Orders behandelen

`node admin.mjs orders` toont betaal- en e-mailstatus. `node admin.mjs withdrawals` toont herroepingen en of een download is gestart. Een herroeping krijgt automatisch een ontvangstbericht en blokkeert verdere downloads. Beoordeel het recht op herroeping en behandel de financiële terugbetaling in Mollie. De app verwerkt de providerstatus en blokkeert downloads bij een volledige terugbetaling, terugboeking of gedeeltelijke terugbetaling in afwachting van beoordeling. Creditnota’s en verwerking van een gedeeltelijke terugbetaling per product gebeuren buiten deze versie. Als een bevestiging na herhaald proberen niet is verzonden, controleer Resend en gebruik daarna zo nodig `node admin.mjs mail-retry <bestelnummer>`.

Klanten ontvangen een privébestelpagina per order. Daar openen ze de factuur en vragen ze links aan die tien minuten geldig zijn. De app bepaalt de prijs en btw opnieuw aan de hand van de gepubliceerde producten en bewaart de orderregels bij de bestelling. De implementatie biedt gastbestellingen per order. Een overkoepelend klantaccount, marketingautomatisering en affiliateprogramma vallen buiten deze bouw.

## Verificatie in dit pakket

De tests controleren catalogusimport, verborgen concepten, 1.000 artikelen met pagina’s van 24, prijzen en btw in checkout, herhaalde checkout, bevestiging, factuur, downloadtoegang en blokkering na herroeping of terugbetaling. De Mollie- en Resend-integratietest werkt met lokale providerantwoorden. De echte Mollie-sandbox, iDEAL, kaartbetaling, e-mailontvangst en productiehosting vragen toegang tot jouw accounts en domein. De catalogustest meet de lokale API zonder overdracht van productbeelden of externe hostingbelasting.
