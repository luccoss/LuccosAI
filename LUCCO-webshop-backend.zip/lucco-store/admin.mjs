import { readFileSync } from 'node:fs';
import { db, transaction, skuPattern, validate } from './store.mjs';

const [command, ...args] = process.argv.slice(2);
switch (command) {
  case 'import': {
    const rows = JSON.parse(readFileSync(args[0], 'utf8'));
    if (!Array.isArray(rows)) throw Error('Gebruik een JSON-lijst.');
    transaction(() => {
      const seen = new Set();
      const upsert = db.prepare('INSERT INTO drafts VALUES (?, ?) ON CONFLICT(sku) DO UPDATE SET data=excluded.data');
      for (const row of rows) {
        if (typeof row?.sku !== 'string' || !skuPattern.test(row.sku) || seen.has(row.sku)) {
          throw Error(`Ontbrekende, ongeldige of dubbele SKU: ${row?.sku}`);
        }
        seen.add(row.sku);
        upsert.run(row.sku, JSON.stringify(row));
      }
    });
    console.log(`${rows.length} concepten geïmporteerd`);
    break;
  }
  case 'publish': {
    transaction(() => {
      if (!args.length) throw Error('Geef de goedgekeurde SKU’s op.');
      for (const sku of args) {
        const draft = db.prepare('SELECT data FROM drafts WHERE sku=?').get(sku);
        if (!draft) throw Error(`Concept ontbreekt: ${sku}`);
        const product = validate(JSON.parse(draft.data));
        db.prepare('INSERT INTO products VALUES (?, ?, 1) ON CONFLICT(sku) DO UPDATE SET data=excluded.data, published=1')
          .run(sku, JSON.stringify(product));
      }
    });
    console.log(`${args.length} producten gepubliceerd`);
    break;
  }
  case 'unpublish':
    for (const sku of args) db.prepare('UPDATE products SET published=0 WHERE sku=?').run(sku);
    break;
  case 'orders':
    console.table(db.prepare('SELECT id, status, gross, payment, invoice, mailed, mail_error FROM orders ORDER BY id DESC LIMIT 100').all());
    break;
  case 'withdrawals':
    console.table(db.prepare(`SELECT orders.id, orders.status, withdrawals.created, withdrawals.mailed, withdrawals.mail_error,
      EXISTS(SELECT 1 FROM downloads WHERE order_id=orders.id) AS downloaded
      FROM orders JOIN withdrawals ON order_id=orders.id ORDER BY withdrawals.created DESC LIMIT 100`).all());
    break;
  case 'catalog':
    console.table(db.prepare(`SELECT drafts.sku, json_extract(drafts.data, '$.title') title,
      coalesce(products.published,0) published FROM drafts LEFT JOIN products USING(sku) ORDER BY drafts.sku`).all());
    break;
  case 'mail-retry':
    if (!args[0] || !/^\d+$/.test(args[0])) throw Error('Geef een ordernummer.');
    db.prepare("UPDATE orders SET mail_after=0, mail_started=NULL, mail_error=NULL WHERE id=? AND mailed IS NULL AND status='paid'").run(Number(args[0]));
    db.prepare('UPDATE withdrawals SET mail_after=0, mail_started=NULL, mail_error=NULL WHERE order_id=? AND mailed IS NULL').run(Number(args[0]));
    break;
  default:
    throw Error('Gebruik import <json>, catalog, publish <sku...>, unpublish <sku...>, orders, withdrawals of mail-retry <id>.');
}
