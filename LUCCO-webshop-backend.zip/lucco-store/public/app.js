const $ = id => document.getElementById(id);
const money = cents => new Intl.NumberFormat('en-IE', { style:'currency', currency:'EUR' }).format(cents / 100);
const h = value => String(value ?? '').replace(/[&<>"']/g, c => ({
  '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'
})[c]);
const cartKey = 'lucco-cart';
const badges = { ebook:'E-book', template:'Template', course:'Mini-course' };
function readCart() {
  try {
    const stored = JSON.parse(localStorage.getItem(cartKey) || '[]');
    if (!Array.isArray(stored)) return [];
    return [...new Set(stored.map(entry => typeof entry === 'string' ? entry : entry?.sku)
      .filter(sku => typeof sku === 'string' && /^[a-zA-Z0-9][a-zA-Z0-9_-]{0,79}$/.test(sku)))].slice(0, 20);
  } catch { return []; }
}
async function get(url) {
  const response = await fetch(url);
  if (!response.ok) throw Error('Request failed');
  return response.json();
}

const grid = $('product-grid');
if (grid) initShop();
function initShop() {
  const products = new Map();
  let cart = readCart();
  let category = 'all';
  let page = 1;
  let request = 0;
  let typing;
  let toast;
  let previousFocus;
  let cartRequest = 0;
  let cartError = false;

  function notice(message) {
    $('toast').textContent = message;
    $('toast').classList.add('show');
    clearTimeout(toast);
    toast = setTimeout(() => $('toast').classList.remove('show'), 2100);
  }
  function renderCart() {
    $('cart-count').textContent = cart.length;
    $('drawer-count').textContent = '(' + cart.length + ')';
    const visible = cart.map(sku => products.get(sku)).filter(Boolean);
    $('cart-total').textContent = money(visible.reduce((sum,p) => sum + p.gross, 0));
    $('cart-items').innerHTML = visible.map(p =>
      `<div class="cart-item"><img src="${h(p.image_url)}" alt=""><div><h3><a href="/p/${h(p.sku)}">${h(p.title)}</a></h3>
      <small>${money(p.gross)}</small></div><button class="remove-item" data-remove="${h(p.sku)}" aria-label="Remove ${h(p.title)}">×</button></div>`
    ).join('') || `<div class="cart-empty">${cartError ? 'Your cart could not be loaded. Refresh the page to try again.' : cart.length ? 'Loading cart…' : 'Your cart is empty.'}</div>`;
    $('checkout-button').disabled = !cart.length || visible.length !== cart.length;
  }
  function saveCart() {
    try { localStorage.setItem(cartKey, JSON.stringify(cart)); } catch {}
    renderCart();
  }
  async function loadCart() {
    const current = ++cartRequest;
    cartError = false;
    if (!cart.length) return renderCart();
    const requested = [...cart];
    try {
      const results = await get('/api/cart?' + new URLSearchParams({ items:requested.join(',') }));
      if (current !== cartRequest) return;
      for (const product of results) products.set(product.sku,product);
      const available = new Set(results.map(product => product.sku));
      const removed = cart.filter(sku => requested.includes(sku) && !available.has(sku));
      cart = cart.filter(sku => !removed.includes(sku));
      if (removed.length) notice('An item in your cart is no longer available.');
      saveCart();
    } catch {
      if (current === cartRequest) { cartError = true; renderCart(); }
    }
  }
  async function render() {
    const current = ++request;
    const params = new URLSearchParams({ category, page, q:$('product-search').value, sort:$('sort-select').value, license:$('license-select').value });
    grid.setAttribute('aria-busy', 'true');
    try {
      const result = await get('/api/catalog?' + params);
      if (current !== request) return;
      page = result.page;
      $('license-control').hidden = !result.hasReseller;
      for (const link of $('categories').querySelectorAll('[data-category]')) {
        link.hidden = link.dataset.category !== 'all' && !result.genres.includes(link.dataset.category);
      }
      const pageCount = Math.max(1, Math.ceil(result.total / result.pageSize));
      for (const p of result.products) products.set(p.sku,p);
      grid.innerHTML = result.products.map(p =>
        `<article class="product-card"><a class="product-image" href="/p/${h(p.sku)}">
        <img src="${h(p.image_url)}" alt="${h(p.image_alt || p.title)}" loading="lazy" decoding="async" width="650" height="700"></a><div class="product-info">
        <p class="product-category">${[badges[p.kind],p.category_label].filter(Boolean).map(h).join(' · ')}</p>
        <div class="product-title-row"><h3 class="product-title"><a href="/p/${h(p.sku)}">${h(p.title)}</a></h3>
        <span class="product-price">${p.discount_from ? `<del>${money(Number(p.discount_from) * 100)}</del> ` : ''}${money(p.gross)}</span></div>
        <p class="product-summary">${h(p.summary)}</p>
        ${p.payhip_url ? `<a class="button add-button" href="${h(p.payhip_url)}">Buy on Payhip ↗</a>` :
          `<button class="add-button" data-add="${h(p.sku)}">Add to cart</button>`}</div></article>`
      ).join('') || '<div class="no-results"><p>No products found.</p><button class="button" data-reset-filter>Clear filters</button></div>';
      $('product-total').textContent = result.total.toLocaleString('en-IE') + ' products';
      $('page-number').textContent = page + ' / ' + pageCount;
      $('previous-page').disabled = page <= 1;
      $('next-page').disabled = page >= pageCount;
    } catch {
      if (current === request) {
        grid.innerHTML = '<div class="no-results" role="status"><p>The catalogue could not be loaded.</p><button class="button" data-retry>Try again</button></div>';
        $('product-total').textContent = '';
        $('page-number').textContent = '';
        $('previous-page').disabled = true;
        $('next-page').disabled = true;
      }
    } finally {
      if (current === request) grid.removeAttribute('aria-busy');
    }
  }
  function changePage(step) {
    page += step;
    void render();
    $('shop').scrollIntoView({ block:'start' });
  }
  function resetPage() { page = 1; void render(); }
  function showCart(open) {
    const drawer = $('cart-drawer');
    if (open) {
      previousFocus = document.activeElement === document.body ? $('cart-open') : document.activeElement;
    }
    drawer.classList.toggle('open', open);
    $('overlay').classList.toggle('open', open);
    drawer.setAttribute('aria-hidden', String(!open));
    drawer.inert = !open;
    $('skip-link').inert = open;
    $('site-header').inert = open;
    $('shop-content').inert = open;
    document.body.classList.toggle('cart-visible',open);
    if (open) $('cart-close').focus();
    else previousFocus?.focus();
  }

  grid.addEventListener('click', event => {
    if (event.target.closest('[data-retry]')) {
      $('product-search').focus();
      return void render();
    }
    if (event.target.closest('[data-reset-filter]')) {
      $('product-search').value = '';
      $('license-select').value = '';
      $('sort-select').value = 'featured';
      $('categories').querySelector('[data-category="all"]').click();
      $('product-search').focus();
      return;
    }
    const sku = event.target.closest('[data-add]')?.dataset.add;
    if (!sku) return;
    if (cart.includes(sku)) return notice('This item is already in your cart.');
    if (cart.length >= 20) return notice('You can order up to 20 items at a time.');
    cart.push(sku);
    saveCart();
    notice(products.get(sku).title + ' added');
  });
  $('cart-items').addEventListener('click', event => {
    const sku = event.target.closest('[data-remove]')?.dataset.remove;
    if (sku) { cart = cart.filter(key => key !== sku); saveCart(); $('cart-close').focus(); }
  });
  $('cart-open').addEventListener('click', () => showCart(true));
  $('cart-close').addEventListener('click', () => showCart(false));
  $('overlay').addEventListener('click', () => showCart(false));
  document.addEventListener('keydown', event => {
    if (!$('cart-drawer').classList.contains('open')) return;
    if (event.key === 'Escape') showCart(false);
    if (event.key !== 'Tab') return;
    const controls = [...$('cart-drawer').querySelectorAll('a[href], button:not(:disabled)')];
    if (event.shiftKey && document.activeElement === controls[0]) {
      event.preventDefault();
      controls.at(-1).focus();
    } else if (!event.shiftKey && document.activeElement === controls.at(-1)) {
      event.preventDefault();
      controls[0].focus();
    }
  });
  $('checkout-button').addEventListener('click', () => {
    if (cart.length) location.assign('/checkout?' + new URLSearchParams({ items:cart.join(',') }));
  });
  $('filter-toggle').addEventListener('click', () => {
    const open = $('catalog-sidebar').classList.toggle('open');
    $('filter-toggle').setAttribute('aria-expanded', String(open));
    $('filter-toggle').querySelector('span').textContent = open ? '−' : '+';
  });
  $('categories').addEventListener('click', event => {
    const link = event.target.closest('[data-category]');
    if (!link || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    const previous = $('categories').querySelector('.active');
    previous.classList.remove('active');
    previous.removeAttribute('aria-current');
    link.classList.add('active');
    link.setAttribute('aria-current','true');
    category = link.dataset.category;
    $('shop-title').textContent = category === 'all' ? 'All e-books' : link.textContent;
    if ($('catalog-sidebar').classList.contains('open') && matchMedia('(max-width: 850px)').matches) {
      $('filter-toggle').click();
      $('filter-toggle').focus();
    }
    resetPage();
  });
  $('product-search').addEventListener('input', () => {
    clearTimeout(typing);
    typing = setTimeout(resetPage, 160);
  });
  $('search-clear').addEventListener('click', () => { $('product-search').value = ''; resetPage(); });
  $('sort-select').addEventListener('change', resetPage);
  $('license-select').addEventListener('change', resetPage);
  $('search-toggle').addEventListener('click', () => { $('product-search').scrollIntoView({ block:'center' }); $('product-search').focus(); });
  $('previous-page').addEventListener('click', () => changePage(-1));
  $('next-page').addEventListener('click', () => changePage(1));
  $('menu-toggle').addEventListener('click', () => {
    $('menu-toggle').setAttribute('aria-expanded', String($('main-nav').classList.toggle('open')));
  });
  $('main-nav').addEventListener('click', event => {
    if (!event.target.closest('a')) return;
    $('main-nav').classList.remove('open');
    $('menu-toggle').setAttribute('aria-expanded','false');
  });
  $('year').textContent = new Date().getFullYear();
  $('cart-drawer').inert = true;
  renderCart();
  void loadCart();
  void render();
  if (new URLSearchParams(location.search).get('winkelmand') === '1') showCart(true);
  window.addEventListener('pageshow', event => {
    if (!event.persisted) return;
    cart = readCart();
    renderCart();
    void loadCart();
  });
}
const detailButton = document.querySelector('[data-add-detail]');
if (detailButton) {
  detailButton.hidden = false;
  detailButton.addEventListener('click', () => {
    const status = $('detail-status');
    const sku = detailButton.dataset.addDetail;
    const stored = readCart();
    status.hidden = false;
    if (stored.includes(sku)) {
      status.textContent = 'This item is already in your cart.';
    } else if (stored.length >= 20) {
      status.textContent = 'You can order up to 20 items at a time.';
    } else {
      try {
        localStorage.setItem(cartKey, JSON.stringify([...stored,sku]));
        status.textContent = 'Added to your cart.';
      } catch {
        status.textContent = 'Your cart could not be saved. You can check out directly.';
        return;
      }
    }
    const link = document.createElement('a');
    link.href = '/?winkelmand=1#shop';
    link.textContent = 'View cart';
    status.append(' ',link);
  });
}
const purchased = document.querySelector('[data-purchased]');
if (purchased) {
  try {
    const removed = new Set(purchased.dataset.purchased.split(','));
    localStorage.setItem(cartKey, JSON.stringify(readCart().filter(sku => !removed.has(sku))));
  } catch {}
}

const checkoutForm = document.querySelector('[data-checkout]');
if (checkoutForm) {
  const submit = checkoutForm.querySelector('[type="submit"]');
  const status = checkoutForm.querySelector('.checkout-status');
  checkoutForm.addEventListener('submit', () => {
    submit.disabled = true;
    status.hidden = false;
    checkoutForm.setAttribute('aria-busy','true');
  });
  window.addEventListener('pageshow', () => {
    submit.disabled = false;
    status.hidden = true;
    checkoutForm.removeAttribute('aria-busy');
  });
}
