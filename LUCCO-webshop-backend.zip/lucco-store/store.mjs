import { DatabaseSync } from 'node:sqlite';
import { constants, copyFileSync, mkdirSync, readFileSync, realpathSync, statSync } from 'node:fs';
import { resolve, sep } from 'node:path';

export const mode = process.env.LUCCO_MODE || 'demo';
if (!['demo', 'test', 'live'].includes(mode)) throw Error('Onbekende LUCCO_MODE');
export const port = Number(process.env.PORT || 3000);
export const base = (process.env.BASE_URL || (process.env.RAILWAY_PUBLIC_DOMAIN && 'https://' + process.env.RAILWAY_PUBLIC_DOMAIN) || `http://127.0.0.1:${port}`).replace(/\/$/, '');
export const root = resolve(process.env.LUCCO_DATA || `./data-${mode}`);
export const seller = Object.fromEntries(
  ['NAME','ADDRESS','VAT','KVK','EMAIL','TERMS_URL','PRIVACY_URL','RETURNS_URL']
    .map(key => [key.toLowerCase(), process.env['SHOP_' + key] || ''])
);
const assets = resolve(root, 'files');
mkdirSync(assets, { recursive: true, mode: 0o700 });
export function privateFile(name) {
  if (!name || resolve(assets, name) === assets) throw Error('Bestand ontbreekt');
  const path = realpathSync(resolve(assets, name));
  if (!path.startsWith(realpathSync(assets) + sep) || !statSync(path).isFile()) {
    throw Error('Ongeldig bestandspad');
  }
  return path;
}
export const db = new DatabaseSync(resolve(root, 'store.sqlite'));
db.exec(`
  PRAGMA journal_mode=WAL;
  PRAGMA busy_timeout=5000;
  CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS products (
    sku TEXT PRIMARY KEY, data TEXT NOT NULL, published INTEGER NOT NULL DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS drafts (
    sku TEXT PRIMARY KEY, data TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY, access TEXT NOT NULL UNIQUE, attempt TEXT NOT NULL UNIQUE,
    customer TEXT NOT NULL, lines TEXT NOT NULL, gross INTEGER NOT NULL, vat INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'open', payment TEXT UNIQUE, checkout TEXT, created INTEGER NOT NULL,
    paid INTEGER, invoice INTEGER UNIQUE, mailed INTEGER, mail_after INTEGER NOT NULL DEFAULT 0,
    mail_started INTEGER, mail_error TEXT, checked INTEGER NOT NULL DEFAULT 0, seller TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS withdrawals (
    order_id INTEGER PRIMARY KEY REFERENCES orders(id), created INTEGER NOT NULL,
    mailed INTEGER, mail_after INTEGER NOT NULL DEFAULT 0, mail_started INTEGER, mail_error TEXT
  );
  CREATE TABLE IF NOT EXISTS downloads (order_id INTEGER NOT NULL, sku TEXT NOT NULL, first_opened INTEGER NOT NULL,
    PRIMARY KEY(order_id,sku));
`);
db.prepare("INSERT OR IGNORE INTO settings VALUES ('mode', ?)").run(mode);
if (db.prepare("SELECT value FROM settings WHERE key='mode'").get().value !== mode) {
  throw Error('Gebruik per omgeving een eigen gegevensmap.');
}
export function transaction(work) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = work();
    db.exec('COMMIT');
    return result;
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
}
export const categories = {
  productivity:'Planning', business:'Business', wellbeing:'Everyday Life', creator:'Content Creation',
  ai:'AI and Workflows', marketing:'Marketing', design:'Design', finance:'Personal Finance', bundles:'Bundles'
};
export const productKinds = { ebook:'E-book', template:'Template', course:'Mini-course' };
Object.assign(categories, {
  ai:'AI and Digital Skills', business:'Business and Freelancing', geld:'Money and Budgeting',
  productiviteit:'Productivity and Personal Development', welzijn:'Food and Wellbeing',
  content:'Marketing and Creative Work', leven:'Life Events', techniek:'Technology and Design',
  thriller:'Thrillers', romantiek:'Romance'
});
export const skuPattern = /^[a-zA-Z0-9][a-zA-Z0-9_-]{0,79}$/;
const cents = value => Math.round(Number(value) * 100);
export function validate(product) {
  for (const field of ['sku','title','category','summary','description','format','image_url','image_alt',
    'language','compatibility','license','rights_ref','image_rights_ref','reviewed_by','file','version']) {
    if (typeof product[field] !== 'string' || !product[field].trim()) throw Error(`Veld ontbreekt: ${field}`);
  }
  if (!skuPattern.test(product.sku) || !Object.hasOwn(categories, product.category)) throw Error('Ongeldige SKU of categorie');
  const localMedia = /^\/media\/[a-z0-9-]+\.webp$/;
  const localImage = value => typeof value === 'string' && localMedia.test(value) &&
    statSync(new URL('./public' + value, import.meta.url), { throwIfNoEntry:false })?.isFile();
  if (!(localImage(product.image_url) || /^https:\/\/[^\s]+$/.test(product.image_url)) || !/^[1-9]\d{0,4}\.\d{2}$|^0\.[0-9]{2}$/.test(String(product.price)) || cents(product.price) < 1) {
    throw Error('Gebruik een HTTPS-afbeelding of meegeleverde omslag en een EUR-prijs met twee decimalen.');
  }
  if (product.preview_url && !localImage(product.preview_url)) throw Error('Voorbeeldafbeelding ontbreekt.');
  if (!Number.isInteger(product.vat) || product.vat < 0 || product.vat > 100) throw Error('Ongeldig btw-tarief');
  if (!['gebruik','reseller'].includes(product.license_type)) throw Error('Kies gebruik of reseller voor license_type.');
  if (product.license_type === 'reseller' && !String(product.downstream_rights || '').trim()) throw Error('Leg de doorverkooprechten expliciet vast.');
  if (!Array.isArray(product.includes) || !product.includes.length || !product.includes.every(item => typeof item === 'string' && item.trim())) throw Error('Beschrijf de inhoud.');
  if (product.kind && !Object.hasOwn(productKinds,product.kind)) throw Error('Ongeldige productsoort.');
  if (product.download_name !== undefined &&
      (typeof product.download_name !== 'string' || !/^[^\x00-\x1f\x7f/\\]{1,140}\.pdf$/i.test(product.download_name) ||
       !product.file.toLowerCase().endsWith('.pdf'))) throw Error('Ongeldige PDF-downloadnaam.');
  const size = statSync(privateFile(product.file)).size;
  if (product.alternative_file && !statSync(privateFile(product.alternative_file)).size) throw Error('Leeg aanvullend bestand.');
  if (!size) throw Error('Leeg downloadbestand.');
  if (product.discount_from && !(Number(product.discount_from) > Number(product.price))) throw Error('Ongeldige referentieprijs.');
  return { ...product, bytes:size, category_label:categories[product.category], gross:cents(product.price) };
}
export function published() {
  return db.prepare('SELECT data FROM products WHERE published=1 ORDER BY rowid').all().map(row => JSON.parse(row.data));
}
export function publicProduct(product) {
  const fields = ['sku','category','category_label','title','summary','description','price','gross','image_url','image_alt',
    'format','kind','minutes','preview_url','includes','language','compatibility','license','license_type','downstream_rights','version','bytes','discount_from','tags'];
  return Object.fromEntries(fields.filter(key => product[key] !== undefined).map(key => [key, product[key]]));
}
export function editionDrafts() {
  const products = JSON.parse(readFileSync(new URL('./catalog-books.json', import.meta.url)));
  const directory = 'lucco-bibliotheek';
  mkdirSync(resolve(assets,directory), { recursive:true, mode:0o700 });
  for (const product of products) {
    if (!skuPattern.test(product.sku)) throw Error('Ongeldig artikel in de catalogus');
    for (const path of [product.file,product.alternative_file].filter(Boolean)) {
      const name = path.slice(directory.length + 1);
      const filePattern = /-v[1-9]\d*\.(pdf|epub|xlsx|pptx|zip)$/;
      const allowed = filePattern.test(name) && name.replace(filePattern,'') === product.sku;
      if (!path.startsWith(directory + '/') || !allowed) throw Error('Ongeldig catalogusbestand');
      try { copyFileSync(new URL('./downloads/' + name, import.meta.url),resolve(assets,path),constants.COPYFILE_EXCL); }
      catch (error) { if (error.code !== 'EEXIST') throw error; }
    }
  }
  return products.map(product => ({
    ...product, license_type:'gebruik',
    license:'For personal use or use within your own organisation. This licence does not permit public distribution or resale.',
    rights_ref:'LUCCO digitale catalogus 2.0', image_rights_ref:'LUCCO digitale catalogus 2.0'
  }));
}
export function seed() {
  if (mode !== 'demo') return;
  const products = editionDrafts();
  transaction(() => {
    if (db.prepare("SELECT 1 FROM settings WHERE key='english-books-2026-11'").get()) return;
    const legacy = JSON.parse(readFileSync(new URL('./demo-products.json', import.meta.url)));
    const retire = db.prepare("UPDATE products SET published=0 WHERE sku=? AND json_extract(data,'$.file')='demo.txt'");
    for (const product of legacy) retire.run(product.sku);
    db.exec("UPDATE products SET published=0 WHERE json_extract(data,'$.file') LIKE 'lucco-editie/%'");
    const keepBooks = JSON.stringify(products.filter(product => product.kind === 'ebook').map(product => product.sku));
    db.prepare(`UPDATE products SET published=0
      WHERE coalesce(json_extract(data,'$.kind'),'ebook')='ebook'
        AND sku NOT IN (SELECT value FROM json_each(?))`).run(keepBooks);
    const insert = db.prepare(`INSERT INTO products VALUES (?, ?, 1)
      ON CONFLICT(sku) DO UPDATE SET data=excluded.data
      WHERE json_extract(products.data,'$.rights_ref')='LUCCO digitale catalogus 2.0'`);
    for (const product of products) {
      const sample = validate({ ...product, vat:21, reviewed_by:'Interne demo' });
      insert.run(sample.sku, JSON.stringify(sample));
    }
    db.exec("INSERT INTO settings VALUES ('english-books-2026-11', '1')");
  });
}
