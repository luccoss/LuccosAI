import assert from 'node:assert/strict';
import { execFileSync, spawn } from 'node:child_process';
import { once } from 'node:events';
import { mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { createServer } from 'node:net';
import { tmpdir } from 'node:os';
import { resolve } from 'node:path';
import { test } from 'node:test';

const cwd = new URL('../', import.meta.url);
const pattern = name => new RegExp(`name="${name}" value="([^"]+)"`);
async function boot(t, { mode = 'demo', mock = false } = {}) {
  const data = mkdtempSync(resolve(tmpdir(),'lucco-tests-'));
  const reservation = createServer().listen(0, '127.0.0.1');
  await once(reservation,'listening');
  const port = reservation.address().port;
  await new Promise((resolveClose,reject) => reservation.close(error => error ? reject(error) : resolveClose()));
  const url = 'http://127.0.0.1:' + port;
  const origin = mock ? 'https://shop.example.com' : url;
  const env = { ...process.env, LUCCO_MODE:mode, LUCCO_DATA:data, BASE_URL:origin, PORT:String(port), HOST:'127.0.0.1',
    ...(mock ? { MOLLIE_API_KEY:'test_fixture', LUCCO_SECRET:'f'.repeat(64), RESEND_API_KEY:'re_fixture', MAIL_FROM:'orders@example.com' } : {}) };
  const worker = spawn(process.execPath, [...(mock ? ['--import','./test/provider-fixture.mjs'] : []), 'server.mjs'],
    { cwd, env, stdio:['ignore','pipe','pipe'] });
  let stderr = '';
  worker.stderr.on('data', buffer => { stderr += buffer; });
  t.after(async () => {
    if (worker.exitCode === null) {
      const exited = once(worker,'exit');
      worker.kill();
      await exited;
    }
    rmSync(data,{ recursive:true, force:true });
  });
  for (let attempt = 0; attempt < 100; attempt++) {
    if (worker.exitCode !== null) assert.fail(stderr);
    try { if ((await fetch(url + '/health')).ok) break; } catch {}
    await new Promise(resolveWait => setTimeout(resolveWait,20));
  }
  const get = path => fetch(url + path, { redirect:'manual' });
  const post = (path, body) => fetch(url + path, { method:'POST', redirect:'manual',
    headers:{ Origin:origin, 'Content-Type':'application/x-www-form-urlencoded' }, body:new URLSearchParams(body) });
  const admin = (...args) => execFileSync(process.execPath,['admin.mjs',...args],{ cwd, env, stdio:'pipe' });
  function draft(index) {
    return { sku:'S' + index, title:'Testproduct ' + index, summary:'Planningsbestand voor catalogustest', description:'Testbestand',
      price:'12.10', vat:21, category:'productivity', image_url:'https://example.com/photo.jpg', image_alt:'Testbeeld',
      license:'Testlicentie', license_type:'gebruik', rights_ref:'internal-contract', image_rights_ref:'image-contract',
      reviewed_by:'Automatische test', file:'test.txt', version:'1', language:'nl', compatibility:'Tekstlezer', format:'TXT', includes:['Tekstbestand'] };
  }
  function load(rows) {
    mkdirSync(resolve(data,'files'),{ recursive:true });
    writeFileSync(resolve(data,'files/test.txt'),'Orderbestand voor integratietests');
    writeFileSync(resolve(data,'drafts.json'),JSON.stringify(rows));
    admin('import', resolve(data,'drafts.json'));
  }
  async function quote(sku) {
    const response = await get('/checkout?items=' + sku);
    assert.equal(response.status, 200);
    const html = await response.text();
    return { items:sku, quote:html.match(pattern('quote'))[1], attempt:html.match(pattern('attempt'))[1],
      name:'Testklant', address:'Teststraat 1', email:'test@example.com', postcode:'1234 AB', city:'Utrecht', consent:'yes' };
  }
  return { get, post, quote, data, admin, draft, load };
}

test('de demo doorloopt checkout, herhaling, factuur, download en terugbetaling', async t => {
  const { get, post, quote, data } = await boot(t);
  const listing = await get('/api/catalog');
  assert.equal(listing.headers.get('x-robots-tag'),'noindex, nofollow');
  assert.match(await (await get('/robots.txt')).text(), /Disallow: \//);
  const { products, total } = await listing.json();
  const home = await (await get('/')).text();
  assert.match(home, /Manrope/);
  assert.match(home, /E-books for/);
  assert.match(home, /showcase-middle/);
  for (const product of ['create-digital-products-with-ai','build-a-side-hustle-alongside-your-job','create-and-sell-online-courses']) {
    assert.match(home,new RegExp('href="/p/' + product + '"'));
    assert.equal((await get('/p/' + product)).status,200);
  }
  const stylesheet = await (await get('/styles.css?v=20261127-english')).text();
  assert.match(stylesheet,/--wine:#1748d8/);
  assert.match(stylesheet,/@media\(max-width:640px\)/);
  assert.equal(total,7);
  assert.equal(products.length,7);
  for (const product of products) {
    assert.ok(product.image_url && product.preview_url);
    assert.ok(!('file' in product) && !('alternative_file' in product));
    for (const asset of [product.image_url,product.preview_url]) {
      const image = await get(asset);
      assert.equal(image.status,200,asset);
      assert.equal(image.headers.get('content-type'),'image/webp');
      await image.arrayBuffer();
    }
  }
  assert.equal((await get('/media/lucco-lectuur.webp')).status,200);
  assert.equal((await get('/downloads/ai-werkdag-v1.pdf')).status,404);
  assert.match(await (await get('/over-ons')).text(), /About LUCCO/);
  for (const [kind,count] of [['ebook',7],['template',0],['course',0]]) {
    const selection=await (await get('/api/catalog?kind=' + kind)).json();
    assert.equal(selection.total,count);
    assert.ok(selection.products.every(p => p.kind === kind));
  }
  const thrillers=await (await get('/api/catalog?kind=ebook&category=thriller')).json();
  assert.equal(thrillers.total,0);
  assert.equal((await get('/p/ai-werkdag')).status,404);
  assert.match(home,/href="\/categories">Browse the shop/);
  const topics = await (await get('/categories')).text();
  for (const category of ['ai','business','content']) {
    assert.match(topics,new RegExp('href="/c/' + category + '"'));
  }
  const ai = await (await get('/c/ai')).text();
  assert.match(ai,/Create Digital Products with AI/);
  assert.doesNotMatch(ai,/ChatGPT for Entrepreneurs/);
  const business = await (await get('/c/business')).text();
  const titles = ['50 Ways to Make Money Online','Build a Side Hustle Alongside Your Job','Print on Demand','Your First EUR 1,000 Online'];
  const positions = titles.map(title => business.indexOf(title));
  assert.ok(positions.every(position => position >= 0));
  assert.deepEqual(positions,[...positions].sort((a,b) => a-b));
  assert.doesNotMatch(home,/Mini-courses|Templates/);
  assert.doesNotMatch(topics,/href="\/c\/geld"/);
  assert.equal((await get('/p/maandbudget-sheet')).status,404);
  assert.equal((await get('/p/cursus-ai-mail')).status,404);
  const books = (await (await get('/api/catalog?kind=ebook')).json()).products;
  assert.deepEqual(books.map(book => book.sku).sort(), [
    '50-ways-to-make-money-online', 'build-a-side-hustle-alongside-your-job',
    'create-and-sell-online-courses', 'create-digital-products-with-ai',
    'make-money-with-a-niche-website', 'print-on-demand-the-complete-guide', 'your-first-1000-euro-online',
  ]);
  assert.equal((await get('/p/chatgpt-for-entrepreneurs')).status,404);
  assert.match(await (await get('/c/ai?kind=course')).text(),/Create Digital Products with AI/);
  assert.match(await (await get('/c/content')).text(),/Create and Sell Online Courses/);
  assert.ok(books.every(book => book.language === 'English' && !/^Lucco/i.test(book.title) && book.description.includes('\n\n')));
  assert.ok(products.every(p => p.language === 'English'));
  const [{sku}] = products;
  assert.match(await (await get('/p/' + sku)).text(), /Usage licence/);
  const form = await quote(sku);
  assert.equal((await post('/checkout',{...form,quote:'0'.repeat(64)})).status,409);
  assert.equal((await post('/checkout',{...form,consent:''})).status,400);
  const attempts = await Promise.all([post('/checkout',form),post('/checkout',form)]);
  assert.equal(attempts[0].status,303);
  const simulator = attempts[0].headers.get('location');
  assert.equal(attempts[1].headers.get('location'),simulator);
  const order = simulator.replace('/demo-pay/','/order/');
  assert.match(await (await get(order)).text(), /Awaiting payment/);
  assert.equal((await get(order + '/download/' + sku)).status,403);
  assert.equal((await get(order + '/invoice')).status,404);
  await post(simulator,{ result:'paid' });
  await post(simulator,{ result:'paid' });
  const html = await (await get(order)).text();
  const download = html.match(/href="([^"]+\/download\/[^"]+)"/)[1].replaceAll('&amp;','&');
  const response = await get(download);
  assert.equal(response.status,200);
  assert.match(response.headers.get('content-disposition'), /attachment/);
  assert.match(response.headers.get('content-disposition'), /\.pdf/);
  assert.equal(Buffer.from(await response.arrayBuffer()).subarray(0,5).toString(),'%PDF-');
  assert.match(response.headers.get('content-disposition'), /Create%20Digital%20Products%20with%20AI\.pdf/);
  assert.equal([...html.matchAll(/href="([^"]+\/download\/[^"]+)"/g)].length,1);
  assert.equal((await get(download + '&bestand=extra')).status,403);
  assert.match(await (await get(order + '/invoice')).text(), /Test invoice L-000001/);
  assert.match(readFileSync(resolve(data,'test-email-1.txt'),'utf8'), /right of withdrawal/);
  assert.equal((await get(download + 'x')).status,403);
  await post(simulator,{ result:'refunded' });
  assert.equal((await get(download)).status,403);
  assert.match(await (await get(order)).text(), /Refunded/);
  const revocation = await post('/checkout',await quote(sku));
  const revocationPath = revocation.headers.get('location');
  const revocationOrder = revocationPath.replace('/demo-pay/','/order/');
  await post(revocationPath,{ result:'paid' });
  const revocationHTML = await (await get(revocationOrder)).text();
  const revocationDownload = revocationHTML.match(/href="([^"]+\/download\/[^"]+)"/)[1].replaceAll('&amp;','&');
  assert.match(await (await get(revocationOrder + '/withdraw')).text(), /Withdraw from purchase/);
  assert.equal((await post(revocationOrder + '/withdraw',{})).status,303);
  assert.equal((await post(revocationOrder + '/withdraw',{})).status,303);
  assert.equal((await get(revocationDownload)).status,403);
  assert.match(await (await get(revocationOrder)).text(), /Withdrawal received/);
  assert.match(readFileSync(resolve(data,'test-withdrawal-2.txt'),'utf8'), /withdrawal request for order 2/);
  const failure = await post('/checkout',await quote(sku));
  const failurePath = failure.headers.get('location');
  const failureResult = await post(failurePath,{ result:'failed' });
  assert.match(await (await get(failureResult.headers.get('location'))).text(), /Try payment again/);
});

test('1.000 catalogusregels, concepten, publicatie, paginering en zoekfunctie', async t => {
  const { get, admin, draft, load } = await boot(t);
  const rows = Array.from({length:1000},(_,index) => draft(index));
  load(rows);
  assert.equal((await get('/p/S0')).status,404);
  load([{...draft(0), rights_ref:''}, ...rows.slice(1)]);
  assert.throws(() => admin('publish','S1','S0'), /rights_ref/);
  assert.equal((await get('/p/S1')).status,404);
  load(rows);
  admin('publish',...rows.map(p => p.sku));
  const samples = [];
  for (let page = 1; page <= 15; page++) {
    const start = performance.now();
    const result = await (await get('/api/catalog?category=productivity&q=planningsbestand&page=' + page)).json();
    samples.push(performance.now() - start);
    assert.equal(result.total,1000);
    assert.equal(result.products.length,24);
    assert.equal(result.page,page);
    assert.equal(result.products[0].sku,'S' + ((page-1)*24));
    assert.ok(!('file' in result.products[0]) && !('rights_ref' in result.products[0]));
  }
  samples.sort((a,b) => a-b);
  t.diagnostic(`Lokale API p50 ${samples[7].toFixed(1)} ms, hoogste meting ${samples.at(-1).toFixed(1)} ms (15 requests, zonder afbeeldingsoverdracht)`);
  const lastPage = await (await get('/api/catalog?category=productivity&q=planningsbestand&page=42')).json();
  assert.equal(lastPage.products.length,16);
  admin('unpublish','S0');
  assert.equal((await get('/p/S0')).status,404);
  assert.equal((await get('/download/test.txt')).status,404);
  assert.equal((await get('/checkout?items=S0')).status,400);
});

test('server controleert providerstatus, bedrag en refund via het Mollie-contract', async t => {
  const { get, post, quote, data, admin, draft, load } = await boot(t,{ mode:'test', mock:true });
  load([draft(0)]);
  admin('publish','S0');
  const result = await post('/checkout', await quote('S0'));
  assert.equal(result.headers.get('location'),'https://www.mollie.com/checkout/test');
  const order = readFileSync(resolve(data,'fixture-order.txt'),'utf8');
  const hook = state => {
    writeFileSync(resolve(data,'fixture-status.txt'),state);
    return post('/webhooks/mollie',{ id:'tr_fixture' });
  };
  assert.match(await (await get(order)).text(), /Awaiting payment/);
  assert.equal((await hook('bad-amount')).status,500);
  assert.match(await (await get(order)).text(), /Awaiting payment/);
  assert.equal((await hook('paid')).status,200);
  assert.equal((await hook('paid')).status,200);
  const html = await (await get(order)).text();
  assert.match(html,/Your downloads/);
  const download = html.match(/href="([^"]+\/download\/[^"]+)"/)[1].replaceAll('&amp;','&');
  assert.equal((await get(download)).status,200);
  assert.match(readFileSync(resolve(data,'fixture-mail.txt'),'utf8'),/order 1/i);
  assert.equal((await hook('refunded')).status,200);
  assert.equal((await get(download)).status,403);
});
