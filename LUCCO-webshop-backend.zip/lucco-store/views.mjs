import { base, mode, seller } from './store.mjs';
export const h = value => String(value ?? '').replace(/[&<>"']/g, c => ({
  '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'
})[c]);
export const money = cents => new Intl.NumberFormat('nl-NL', { style:'currency', currency:'EUR' }).format(cents / 100);
export const date = timestamp => new Intl.DateTimeFormat('nl-NL', { dateStyle:'medium', timeZone:'Europe/Amsterdam' }).format(timestamp);
export const dateTime = timestamp => new Intl.DateTimeFormat('nl-NL', { dateStyle:'long', timeStyle:'short', timeZone:'Europe/Amsterdam' }).format(timestamp);
export const consent = 'Ik verzoek om directe levering van de digitale inhoud en erken dat mijn bedenktijd vervalt zodra ik begin met downloaden.';
export function legalLink(kind, label) {
  return `<a href="${h(seller[kind + '_url'] || '/help#' + kind)}">${h(label)}</a>`;
}
export function page(title, content, options = {}) {
  return `<!doctype html><html lang="nl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>${h(title)} | LUCCO</title><meta name="description" content="${h(options.description || 'Digitale tools van LUCCO')}">
    ${options.canonical ? `<link rel="canonical" href="${h(base + options.canonical)}">` : ''}
    <link rel="stylesheet" href="/styles.css"><script src="/app.js" defer></script></head><body>
    ${mode === 'live' ? '' : `<div class="preview-strip">${mode === 'demo' ? 'DEMO · Simulatie zonder betaling' : 'TESTOMGEVING · Geen echte afschrijving'}</div>`}
    <header class="site-header sub-header"><a class="brand" href="/">LUCCO<span class="brand-dot">.</span></a>
    <a href="/#shop">Naar de collectie ↗</a></header><main class="shop-section inner-page">${content}</main>
    <footer class="footer"><a class="brand" href="/">LUCCO<span class="brand-dot">.</span></a>
    <div><a href="/withdraw">Koop ongedaan maken</a><a href="/help">Contact</a>${legalLink('privacy','Privacy')}${legalLink('terms','Voorwaarden')}${legalLink('returns','Levering en herroeping')}</div></footer></body></html>`;
}
export function productView(product) {
  const { sku, title, category_label, image_url, image_alt, format, summary, description, includes,
    downstream_rights, license, license_type, language, compatibility, version, bytes, gross, discount_from } = product;
  return page(title, `<article class="detail-layout"><img class="detail-cover" src="${h(image_url)}" alt="${h(image_alt)}">
    <div class="flow"><p class="eyebrow">${h(category_label)} · ${license_type === 'reseller' ? 'Resellerlicentie' : 'Gebruikslicentie'}</p>
    <h1>${h(title)}</h1><p class="lead">${h(summary)}</p>
    <p class="detail-price">${discount_from ? `<del>${money(Number(discount_from) * 100)}</del> ` : ''}${money(gross)} <small>incl. btw</small></p>
    <a class="button button-dark" href="/checkout?items=${encodeURIComponent(sku)}" data-direct="${h(sku)}">Afrekenen ↗</a>
    <p>${h(description)}</p><h2>Wat je krijgt</h2><ul>${(includes || []).map(item => `<li>${h(item)}</li>`).join('')}</ul>
    <dl class="specs"><dt>Formaat</dt><dd>${h(format)}</dd><dt>Taal</dt><dd>${h(language)}</dd><dt>Geschikt voor</dt><dd>${h(compatibility)}</dd>
    <dt>Versie</dt><dd>${h(version)}</dd>${bytes ? `<dt>Grootte</dt><dd>${h(bytes.toLocaleString('nl-NL'))} bytes</dd>` : ''}</dl>
    <h2>Licentie</h2><p>${h(license)}</p>${downstream_rights ? `<p>${h(downstream_rights)}</p>` : ''}</div></article>`,
  { description:summary, canonical:'/p/' + sku });
}
export function checkoutView(lines, quote, attempt, error = '') {
  return page('Afrekenen', `<h1>Afrekenen</h1><div class="checkout-layout">
    <form class="order-panel flow" method="post" action="/checkout">
    ${error ? `<p class="error" role="alert">${h(error)}</p>` : ''}
    <input type="hidden" name="items" value="${h(lines.map(p => p.sku).join(','))}">
    <input type="hidden" name="quote" value="${h(quote)}"><input type="hidden" name="attempt" value="${h(attempt)}">
    <h2>Factuurgegevens</h2><label>Volledige naam<input name="name" maxlength="120" required autocomplete="name"></label>
    <label>E-mailadres<input name="email" type="email" maxlength="254" required autocomplete="email"></label>
    <label>Straat en huisnummer<input name="address" maxlength="150" required autocomplete="street-address"></label>
    <div class="field-pair"><label>Postcode<input name="postcode" maxlength="7" required autocomplete="postal-code" placeholder="1234 AB"></label>
    <label>Woonplaats<input name="city" maxlength="100" required autocomplete="address-level2"></label></div>
    <p>Factuur- en woonland Nederland. Digitale levering.</p>
    <label class="check"><input type="checkbox" name="consent" value="yes" required><span>${h(consent)}</span></label>
    <p>Lees de ${legalLink('terms','voorwaarden')}, ${legalLink('returns','informatie over bedenktijd en levering')} en de ${legalLink('privacy','privacyverklaring')}. Je kunt ook via <a href="/withdraw">Koop ongedaan maken</a> herroepen.</p>
    <button class="button button-dark" type="submit">${mode === 'demo' ? 'Start testbetaling' : 'Bestellen met betaalverplichting'} ↗</button>
    </form><aside class="order-panel flow"><h2>Besteloverzicht</h2>
    ${lines.map(line => `<p class="price-row"><a href="/p/${h(line.sku)}">${h(line.title)}</a><b>${money(line.gross)}</b></p>`).join('')}
    <p class="price-row"><span>Totaal incl. btw</span><strong>${money(lines.reduce((sum, p) => sum + p.gross, 0))}</strong></p>
    <p class="price-row"><span>Waarvan btw</span><span>${money(lines.reduce((sum, p) => sum + p.tax, 0))}</span></p>
    <p>${mode === 'demo' ? 'Je kunt de betaalstatus simuleren.' : 'Kies een beschikbare betaalmethode op de betaalpagina van Mollie.'}</p></aside></div>`);
}
export function invoiceView(order) {
  const customer = JSON.parse(order.customer);
  const shop = JSON.parse(order.seller);
  return page(mode === 'live' ? 'Factuur' : 'Testfactuur', `<article class="order-panel flow">
    <h1>${mode === 'live' ? 'Factuur' : 'Testfactuur'} L-${String(order.invoice).padStart(6,'0')}</h1><p>Factuurdatum en betaaldatum ${date(order.paid)}</p>
    <div class="field-pair"><div><h2>Verkoper</h2><p>${h(shop.name || 'LUCCO demo')}<br>${h(shop.address)}<br>BTW ${h(shop.vat)}<br>KVK ${h(shop.kvk)}</p></div>
    <div><h2>Klant</h2><p>${h(customer.name)}<br>${h(customer.address)}<br>${h(customer.postcode)} ${h(customer.city)}<br>Nederland</p></div></div>
    <div class="table-wrap"><table><thead><tr><th>Digitale producten</th><th>Aantal</th><th>Excl. btw</th><th>Tarief</th><th>Btw</th><th>Incl. btw</th></tr></thead>
    <tbody>${JSON.parse(order.lines).map(p => `<tr><td>${h(p.title)}</td><td>1</td><td>${money(p.gross - p.tax)}</td><td>${p.vat}%</td><td>${money(p.tax)}</td><td>${money(p.gross)}</td></tr>`).join('')}</tbody></table></div>
    <p>Btw ${money(order.vat)} · Totaal excl. btw ${money(order.gross - order.vat)}</p>
    <strong>Totaal incl. btw ${money(order.gross)}</strong></article>`);
}
