import { base, mode, productKinds, seller } from './store.mjs';
export const h = value => String(value ?? '').replace(/[&<>"']/g, c => ({
  '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'
})[c]);
export const money = cents => new Intl.NumberFormat('en-IE', { style:'currency', currency:'EUR' }).format(cents / 100);
export const date = timestamp => new Intl.DateTimeFormat('en-IE', { dateStyle:'medium', timeZone:'Europe/Amsterdam' }).format(timestamp);
export const dateTime = timestamp => new Intl.DateTimeFormat('en-IE', { dateStyle:'long', timeStyle:'short', timeZone:'Europe/Amsterdam' }).format(timestamp);
export const consent = 'I request immediate delivery of the digital content and acknowledge that my right of withdrawal ends once I start downloading it.';
export function legalLink(kind, label) {
  return `<a href="${h(seller[kind + '_url'] || '/help#' + kind)}">${h(label)}</a>`;
}
export function page(title, content, options = {}) {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>${h(title)} | LUCCO</title><meta name="description" content="${h(options.description || 'Digital publications from LUCCO')}">
    ${options.canonical ? `<link rel="canonical" href="${h(base + options.canonical)}">` : ''}
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&amp;display=swap">
    <link rel="stylesheet" href="/styles.css?v=20261128-excerpts"><script src="/app.js?v=20261128-payhip" defer></script></head><body>
    ${mode === 'live' ? '' : `<div class="preview-strip">${mode === 'demo' ? 'LUCCO checkout · Payments are simulated' : 'Test store · Payments are simulated'}</div>`}
    <header class="site-header sub-header"><a class="brand" href="/" aria-label="LUCCO homepage">lucco<span aria-hidden="true">.</span></a>
    <a href="/categories">Back to the shop ↗</a></header><main class="shop-section inner-page">${content}</main>
    <footer class="footer"><div class="wrap footer-inner"><a class="brand" href="/" aria-label="LUCCO homepage">lucco<span aria-hidden="true">.</span></a>
    <div class="footer-links"><a href="/over-ons">About</a><a href="/withdraw">Withdraw from purchase</a><a href="/help">Customer Support</a>${legalLink('privacy','Privacy')}${legalLink('terms','Terms')}${legalLink('returns','Delivery and withdrawal')}</div></div></footer></body></html>`;
}
export function productView(product, hasSample = false) {
  const { sku, title, category_label, image_url, image_alt, format, summary, description, includes,
    downstream_rights, license, license_type, language, compatibility, version, bytes, gross, discount_from, preview_url, kind, minutes, payhip_url } = product;
  return page(title, `<article class="detail-layout"><div class="detail-cover-frame"><img class="detail-cover" src="${h(image_url)}" alt="${h(image_alt)}">
    ${hasSample ? `<a class="preview-link" href="/p/${h(sku)}/sample">Read a sample ↗</a>` :
      preview_url ? `<a class="preview-link" href="${h(preview_url)}" target="_blank" rel="noopener">Preview a sample page ↗</a>` : ''}</div>
    <div class="flow"><p class="eyebrow">${h(productKinds[kind] || 'Digital publication')} · ${h(category_label)}</p>
    <h1>${h(title)}</h1><p class="lead">${h(summary)}</p>
    <p class="detail-price">${discount_from ? `<del>${money(Number(discount_from) * 100)}</del> ` : ''}${money(gross)} <small>incl. VAT</small></p>
    <div class="product-actions">${payhip_url ?
      `<a class="button button-dark" href="${h(payhip_url)}">Buy now on Payhip ↗</a>` :
      `<button class="button button-dark" data-add-detail="${h(sku)}" hidden>Add to cart</button>
      <a class="button" href="/checkout?items=${encodeURIComponent(sku)}">Buy now ↗</a>`}</div>
    ${payhip_url ? '<p>Payhip processes the payment and delivers the PDF.</p>' : ''}
    <p id="detail-status" role="status" hidden></p>
    ${description.split(/\n\s*\n/).map(paragraph => `<p>${h(paragraph)}</p>`).join('')}<h2>What’s included</h2><ul>${(includes || []).map(item => `<li>${h(item)}</li>`).join('')}</ul>
    <dl class="specs"><dt>Format</dt><dd>${h(format)}</dd><dt>Language</dt><dd>${h(language)}</dd><dt>Compatibility</dt><dd>${h(compatibility)}</dd>
    ${minutes ? `<dt>Study time</dt><dd>${h(minutes)} minutes</dd>` : ''}
    <dt>Edition</dt><dd>${h(version)}</dd>${bytes ? `<dt>File size</dt><dd>${h(bytes.toLocaleString('en-IE'))} bytes</dd>` : ''}</dl>
    <h2>Usage licence</h2><p>${h(license)}</p>${downstream_rights ? `<p>${h(downstream_rights)}</p>` : ''}</div></article>`,
  { description:summary, canonical:'/p/' + sku });
}
export function bookSampleView(product, sample) {
  const productPath = '/p/' + encodeURIComponent(product.sku);
  return page('Sample from ' + product.title, `<article class="book-sample">
    <a href="${productPath}">← Back to the e-book</a>
    <header>
      <p class="eyebrow">Reading sample · Chapter 1</p>
      <h1>${h(product.title)}</h1>
      <p>This excerpt comes from the e-book. The complete PDF is available after purchase.</p>
    </header>
    <section class="book-excerpt" aria-labelledby="excerpt-heading">
      <h2 id="excerpt-heading">${h(sample.heading)}</h2>
      <p>${h(sample.paragraph)}</p>
      <h3>${h(sample.subheading)}</h3>
      ${sample.detail ? `<p>${h(sample.detail)}</p>` : ''}
      ${sample.list ? `<ul>${sample.list.map(line => `<li>${h(line)}</li>`).join('')}</ul>` : ''}
      ${sample.ordered ? `<ol>${sample.ordered.map(line => `<li>${h(line)}</li>`).join('')}</ol>` : ''}
      ${sample.definitions ? `<dl>${sample.definitions.map(([term,definition]) => `<div><dt>${h(term)}</dt><dd>${h(definition)}</dd></div>`).join('')}</dl>` : ''}
    </section>
    <a class="button" href="${productPath}">Back to the e-book ↗</a>
  </article>`);
}
export function checkoutView(lines, quote, attempt, error = '') {
  return page('Checkout', `<h1>Checkout</h1><div class="checkout-layout">
    <form class="order-panel flow" method="post" action="/checkout" data-checkout>
    ${error ? `<p class="error" role="alert">${h(error)}</p>` : ''}
    <input type="hidden" name="items" value="${h(lines.map(p => p.sku).join(','))}">
    <input type="hidden" name="quote" value="${h(quote)}"><input type="hidden" name="attempt" value="${h(attempt)}">
    <h2>Billing details</h2><label>Full name<input name="name" maxlength="120" required autocomplete="name"></label>
    <label>Email address<input name="email" type="email" maxlength="254" required autocomplete="email"></label>
    <label>Street and house number<input name="address" maxlength="150" required autocomplete="street-address"></label>
    <div class="field-pair"><label>Postcode<input name="postcode" maxlength="7" required autocomplete="postal-code" placeholder="1234 AB"></label>
    <label>City<input name="city" maxlength="100" required autocomplete="address-level2"></label></div>
    <p>Digital delivery. Billing and residence must be in the Netherlands.</p>
    <label class="check"><input type="checkbox" name="consent" value="yes" required><span>${h(consent)}</span></label>
    <p>Read the ${legalLink('terms','terms')}, ${legalLink('returns','delivery and withdrawal information')} and the ${legalLink('privacy','privacy notice')}. You can also <a href="/withdraw">submit a withdrawal request</a>.</p>
    <button class="button button-dark" type="submit">${mode === 'demo' ? 'Start simulated payment' : 'Place order and pay'} ↗</button><p class="checkout-status" role="status" hidden>Processing your order…</p>
    </form><aside class="order-panel flow"><h2>Order summary</h2>
    ${lines.map(line => `<p class="price-row"><a href="/p/${h(line.sku)}">${h(line.title)}</a><b>${money(line.gross)}</b></p>`).join('')}
    <p class="price-row"><span>Total incl. VAT</span><strong>${money(lines.reduce((sum, p) => sum + p.gross, 0))}</strong></p>
    <p class="price-row"><span>VAT included</span><span>${money(lines.reduce((sum, p) => sum + p.tax, 0))}</span></p>
    <p>${mode === 'demo' ? 'You can simulate a payment.' : 'Choose an available payment method on the Mollie checkout page.'}</p></aside></div>`);
}
export function invoiceView(order) {
  const customer = JSON.parse(order.customer);
  const shop = JSON.parse(order.seller);
  return page(mode === 'live' ? 'Invoice' : 'Test invoice', `<article class="order-panel flow">
    <h1>${mode === 'live' ? 'Invoice' : 'Test invoice'} L-${String(order.invoice).padStart(6,'0')}</h1><p>Invoice and payment date ${date(order.paid)}</p>
    <div class="field-pair"><div><h2>Seller</h2><p>${h(shop.name || 'LUCCO demo')}<br>${h(shop.address)}<br>VAT ${h(shop.vat)}<br>KVK ${h(shop.kvk)}</p></div>
    <div><h2>Customer</h2><p>${h(customer.name)}<br>${h(customer.address)}<br>${h(customer.postcode)} ${h(customer.city)}<br>The Netherlands</p></div></div>
    <div class="table-wrap"><table><thead><tr><th>Digital products</th><th>Quantity</th><th>Excl. VAT</th><th>Rate</th><th>VAT</th><th>Incl. VAT</th></tr></thead>
    <tbody>${JSON.parse(order.lines).map(p => `<tr><td>${h(p.title)}</td><td>1</td><td>${money(p.gross - p.tax)}</td><td>${p.vat}%</td><td>${money(p.tax)}</td><td>${money(p.gross)}</td></tr>`).join('')}</tbody></table></div>
    <p>VAT ${money(order.vat)} · Total excl. VAT ${money(order.gross - order.vat)}</p>
    <strong>Total incl. VAT ${money(order.gross)}</strong></article>`);
}
