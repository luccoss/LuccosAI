# Publish LUCCO on Railway

1. Open the GitHub repository connected to the existing Railway service.
2. Upload this archive with its original filename, `LUCCO-webshop-backend.zip`, to the repository root. If the root does not already have the matching `Dockerfile` and `railway.json`, extract those two files from the archive and put them next to it. Commit to the branch Railway follows.
3. In Railway, use `PORT=3000` and set the public domain’s target port to 3000. Clear any custom Start Command that overrides the Dockerfile.
4. After the deployment is active, open the domain currently shown under **Settings → Networking**. Its `/health` endpoint should return `{"status":"ok","mode":"demo"}`. The homepage runs in demo mode with seven English e-books. **Browse the shop** opens the categories page.
5. Test payments use fictitious customer details. Live payments and email require the configuration in `lucco-store/README.md`.

The demo update retires old e-books, templates and mini-courses from public listings during startup. Keep the existing data volume to preserve order records and files for already purchased editions. Use a separate catalogue approval and publication step in test or live mode. Review the rights and tax settings before publishing there.
