# LUCCO op Railway

## Publiceren vanuit GitHub

1. Gebruik de bestaande GitHub-repository die aan uw LUCCO-service op Railway gekoppeld is.
2. Upload `LUCCO-webshop-backend.zip` onder exact die naam naar de hoofdmap van de repository en commit naar de gekoppelde branch. Kopieer indien nodig ook `Dockerfile` en `railway.json` uit deze ZIP naast de ZIP naar GitHub. `Dockerfile` en `railway.json` werken in deze opzet op repositoryniveau.
3. Controleer in de bestaande service in Railway of `PORT` en de Target Port van uw openbare domein allebei `3000` zijn. Laat een eerder ingestelde aangepaste Start Command leeg als die de opdracht uit het Dockerfile overschrijft. De service gebruikt automatisch de Railway-URL, tenzij `BASE_URL` expliciet is opgegeven.
4. Wacht in **Deployments** op een actieve deployment. Open uw Railway-link met `/health` erachter. Verwacht `{"status":"ok","mode":"demo"}`. Open daarna de startpagina. Deze toont 65 artikelen en de witte LUCCO-vormgeving met blauwe accenten.
5. Gebruik de demobetaalroute met fictieve gegevens. Bij echte verkoop gebruikt u een afzonderlijke permanente opslagmap en de Mollie- en e-mailconfiguratie uit `lucco-store/README.md`.

Als GitHub en Railway nog niet gekoppeld zijn, geef de Railway-app toegang tot alleen de webshoprepository en selecteer die onder **LuccosAI → Settings → Source**. De configuratie werkt zonder een nieuwe service aan te maken. De gezondheidstest voorkomt dat Railway een nieuwe release activeert voordat de server reageert.

## Wat zit in dit pakket

- 37 Nederlandstalige e-books, elk als PDF en EPUB. De vier korte verhalen zijn fictie. Het praktische assortiment onder meer bevat stapsgewijze gidsen voor AI, freelancen, budget, organisatie en voeding.
- 16 templates met PDF-handleidingen, waaronder 14 XLSX-bestanden, één Notion-importpakket en één bewerkbaar PowerPoint-bestand met drie Canva-importeerbare ontwerpen. Canva en Notion beperken import op mobiel. Raadpleeg de handleiding van de aanbieder.
- 12 zelfstudiecursussen met drie lessen per cursus, oefeningen en eindcontrole. De aangegeven 35–55 minuten omvatten de oefentijd. De cursussen bestaan uit PDF-lespakketten.
- Omslagen, voorbeeldpagina’s, genre- en productfilters, een pagina Over ons, winkelmand, checkout, orderafhandeling en privédownloads.
- In `editorial` staan teksten en de generator waarmee u de productdocumenten kunt aanpassen en opnieuw genereren. Installeer voor regeneratie Python, ReportLab, Pillow, OpenPyXL, python-pptx, pypdf, DejaVu Fonts en Poppler. Voor het draaien van de webshop zijn deze Python-pakketten niet nodig.

Aanleiding voor de onderwerpkeuze waren onder meer de Nederlandstalige ranglijsten van Kobo en Apple Books en het bestaande aanbod aan plannertemplates op Etsy. Dat laat zichtbare genres en marktactiviteit zien. De meegestuurde LUCCO-titels zijn nieuw en hebben nog geen verkoopgeschiedenis.
