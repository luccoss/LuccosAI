#!/bin/sh
set -eu
umask 077

# Gebruik hiervoor een toegestaan bestand dat de leverancier heeft geleverd.
# Deze opdracht bewaart de bronfeed en schrijft uitsluitend concepten.
if [ "$#" -ne 1 ]; then
  printf 'Gebruik: ./import-feed.sh leveranciersfeed.csv\n' >&2
  exit 2
fi
data_directory="$(node --env-file-if-exists=.env -p 'process.env.LUCCO_DATA || ""')"
if [ -z "$data_directory" ]; then
  printf 'Stel LUCCO_DATA in op de databestandmap van de doelomgeving.\n' >&2
  exit 2
fi
archive="$(mktemp -d "${TMPDIR:-/tmp}/lucco-feed.XXXXXXXX")"
trap 'rm -rf "$archive"' EXIT
cp "$1" "$archive/source.csv"
python3 import_csv.py "$archive/source.csv" "$archive/drafts.json"
mkdir -p "$data_directory/imports"
run="$(mktemp -d "$data_directory/imports/feed.XXXXXXXX")"
cp "$archive/source.csv" "$run/source.csv"
node --env-file-if-exists=.env admin.mjs import "$archive/drafts.json"
printf 'Bronfeed opgeslagen in %s\n' "$run"
