"""Convert an authorized feed to draft rows. Review the output before publishing."""
import csv
import json
import sys

source, target = sys.argv[1:]
with open(source, encoding="utf-8-sig", newline="") as stream:
    sample = stream.read(4096)
    stream.seek(0)
    dialect = csv.Sniffer().sniff(sample.splitlines()[0], delimiters=",;\t")
    rows = list(csv.DictReader(stream, dialect=dialect))

for row in rows:
    row["includes"] = [item.strip() for item in row.get("includes", "").split("|") if item.strip()]
    row["price"] = row.get("price", "").replace(",", ".").strip()
    value = row.get("vat", "").strip()
    row["vat"] = int(value) if value.isdecimal() else None

with open(target, "w", encoding="utf-8") as stream:
    json.dump(rows, stream, ensure_ascii=False, indent=2)
