import { base, db, mode, transaction } from './store.mjs';

const apiKey = process.env.MOLLIE_API_KEY;
export const amount = cents => (cents / 100).toFixed(2);
export const confirmed = order => order?.status === 'paid';
const get = id => db.prepare('SELECT * FROM orders WHERE id=?').get(id);
const inFlight = new Map();
async function mollie(path, body, key) {
  const headers = { Authorization: 'Bearer ' + apiKey };
  if (body) Object.assign(headers, { 'Content-Type':'application/json', 'Idempotency-Key':key });
  const response = await fetch('https://api.mollie.com/v2/' + path, {
    method: body ? 'POST' : 'GET', headers, body: body && JSON.stringify(body),
    signal: AbortSignal.timeout(12_000)
  });
  if (!response.ok) throw Error(`Mollie HTTP ${response.status}`);
  return response.json();
}
export async function startPayment(order) {
  if (order.checkout) return order.checkout;
  if (mode === 'demo') return '/demo-pay/' + order.access;
  if (Date.now() - order.created >= 50 * 60_000) throw Error('Betaalpoging verlopen');
  const payload = {
    amount: { currency:'EUR', value:amount(order.gross) },
    description: 'LUCCO bestelling ' + order.id,
    redirectUrl: base + '/order/' + order.access,
    webhookUrl: base + '/webhooks/mollie',
    locale:'nl_NL', metadata:{ order:order.id }
  };
  const payment = await mollie('payments', payload, order.attempt);
  const checkout = new URL(payment._links.checkout.href);
  if (!/^tr_[\w-]+$/.test(payment.id) || checkout.protocol !== 'https:') throw Error('Ongeldige checkout bij Mollie');
  db.prepare('UPDATE orders SET payment=?, checkout=? WHERE id=? AND (payment IS NULL OR payment=?)')
    .run(payment.id, checkout.href, order.id, payment.id);
  return checkout.href;
}
function apply(order, status, checked) {
  transaction(() => {
    const current = get(order.id);
    if (current.checked > checked) return;
    if (['refunded','chargeback'].includes(current.status)) status = current.status;
    if (current.status === 'paid' && ['open','pending','authorized','failed','expired','canceled'].includes(status)) status = 'paid';
    if (status === 'paid' && !current.paid) {
      db.prepare(`UPDATE orders SET paid=?, invoice=(SELECT coalesce(max(invoice),0)+1 FROM orders) WHERE id=?`)
        .run(checked, order.id);
    }
    db.prepare('UPDATE orders SET status=?, checked=? WHERE id=?').run(status, checked, order.id);
  });
}
export function demoResult(order, status) {
  if (mode !== 'demo') throw Error('Alleen voor demo');
  if (status === 'refunded' && order.status !== 'paid') return;
  if (status !== 'refunded' && order.status !== 'open') return;
  apply(order, status, Date.now());
}
export async function refresh(order) {
  if (mode === 'demo' || !order.payment) return get(order.id);
  if (inFlight.has(order.id)) return inFlight.get(order.id);
  const work = (async () => {
    // Mollie is authoritative. Webhook payloads supply only a lookup ID.
    const checked = Date.now();
    const payment = await mollie('payments/' + encodeURIComponent(order.payment));
    if (payment.id !== order.payment || payment.mode !== mode || payment.metadata?.order !== order.id ||
        payment.amount?.currency !== 'EUR' || payment.amount.value !== amount(order.gross)) {
      throw Error('Betaling komt niet overeen met de bestelling');
    }
    let status = payment.status;
    if (Number(payment.amountChargedBack?.value) > 0) status = 'chargeback';
    else if (Number(payment.amountRefunded?.value) >= order.gross / 100) status = 'refunded';
    else if (Number(payment.amountRefunded?.value) > 0) status = 'review';
    if (!['open','pending','authorized','paid','failed','expired','canceled','refunded','chargeback','review'].includes(status)) {
      throw Error('Onbekende status van Mollie');
    }
    apply(order, status, checked);
    return get(order.id);
  })().finally(() => inFlight.delete(order.id));
  inFlight.set(order.id, work);
  return work;
}
