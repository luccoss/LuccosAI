const $ = id => document.getElementById(id);
const money = cents => new Intl.NumberFormat('nl-NL', { style:'currency', currency:'EUR' }).format(cents / 100);
const h = value => String(value ?? '').replace(/[&<>"']/g, c => ({
  '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'
})[c]);
const cartKey = 'lucco-cart';
function readCart() {
  try {
    const stored = JSON.parse(localStorage.getItem(cartKey) || '[]');
    if (!Array.isArray(stored)) return [];
    return [...new Set(stored.map(entry => typeof entry === 'string' ? entry : entry?.sku)
      .filter(sku => typeof sku === 'string' && /^[a-zA-Z0-9][a-zA-Z0-9_-]{0,79}$/.test(sku)))].slice(0, 20);
  } catch { return []; }
}
async function get(url) {
  const response = await fetch(url);
  if (!response.ok) throw Error('Ophalen mislukt');
  return response.json();
}

const grid = $('product-grid');
if (grid) initShop();
function initShop() {
  const products = new Map();
  let cart = readCart();
  let category = 'all';
  let page = 1;
  let request = 0;
  let typing;
  let toast;
  let previousFocus;
  let cartError = false;

  function notice(message) {
    $('toast').textContent = message;
    $('toast').classList.add('show');
    clearTimeout(toast);
    toast = setTimeout(() => $('toast').classList.remove('show'), 2100);
  }
  function renderCart() {
    $('cart-count').textContent = cart.length;
    $('drawer-count').textContent = '(' + cart.length + ')';
    const visible = cart.map(sku => products.get(sku)).filter(Boolean);
    $('cart-total').textContent = money(visible.reduce((sum,p) => sum + p.gross, 0));
    $('cart-items').innerHTML = visible.map(p =>
      `<div class="cart-item"><img src="${h(p.image_url)}" alt=""><div><h3><a href="/p/${h(p.sku)}">${h(p.title)}</a></h3>
      <small>${money(p.gross)}</small></div><button class="remove-item" data-remove="${h(p.sku)}" aria-label="Verwijder ${h(p.title)}">×</button></div>`
    ).join('') || `<div class="cart-empty">${cartError ? 'Uw winkelmand kon niet worden geladen. Vernieuw de pagina om het opnieuw te proberen.' : cart.length ? 'Winkelmand laden…' : 'Uw winkelmand is leeg.'}</div>`;
    $('checkout-button').disabled = !cart.length || visible.length !== cart.length;
  }
  function saveCart() {
    try { localStorage.setItem(cartKey, JSON.stringify(cart)); } catch {}
    renderCart();
  }
  async function loadCart() {
    if (!cart.length) return renderCart();
    const requested = [...cart];
    try {
      for (const p of await get('/api/cart?' + new URLSearchParams({ items:requested.join(',') }))) products.set(p.sku,p);
      const removed = cart.filter(sku => requested.includes(sku) && !products.has(sku));
      cart = cart.filter(sku => !removed.includes(sku));
      if (removed.length) notice('Een artikel in uw winkelmand is niet meer beschikbaar.');
      saveCart();
    } catch { cartError = true; renderCart(); }
  }
  async function render() {
    const current = ++request;
    const params = new URLSearchParams({ category, page, q:$('product-search').value, sort:$('sort-select').value, license:$('license-select').value });
    grid.setAttribute('aria-busy', 'true');
    try {
      const result = await get('/api/catalog?' + params);
      if (current !== request) return;
      page = result.page;
      $('license-control').hidden = !result.hasReseller;
      const pageCount = Math.max(1, Math.ceil(result.total / result.pageSize));
      for (const p of result.products) products.set(p.sku,p);
      grid.innerHTML = result.products.map(p =>
        `<article class="product-card"><a class="product-image" href="/p/${h(p.sku)}">
        <img src="${h(p.image_url)}" alt="${h(p.image_alt || p.title)}" loading="lazy" decoding="async" width="780" height="570"></a><div class="product-info">
        <p class="product-category">${p.license_type === 'reseller' ? 'Resellerlicentie' : h(p.category_label)}</p>
        <div class="product-title-row"><h3 class="product-title"><a href="/p/${h(p.sku)}">${h(p.title)}</a></h3>
        <span class="product-price">${p.discount_from ? `<del>${money(Number(p.discount_from) * 100)}</del> ` : ''}${money(p.gross)}</span></div>
        <p class="product-summary">${h(p.summary)}</p><button class="add-button" data-add="${h(p.sku)}">In winkelmand</button></div></article>`
      ).join('') || '<p class="no-results">Er zijn geen artikelen gevonden.</p>';
      $('product-total').textContent = result.total.toLocaleString('nl-NL') + ' artikelen';
      $('page-number').textContent = page + ' / ' + pageCount;
      $('previous-page').disabled = page <= 1;
      $('next-page').disabled = page >= pageCount;
    } catch {
      if (current === request) grid.innerHTML = '<p class="no-results">De werkboeken konden niet worden geladen. Vernieuw de pagina.</p>';
    } finally {
      if (current === request) grid.removeAttribute('aria-busy');
    }
  }
  function changePage(step) {
    page += step;
    void render();
    $('shop').scrollIntoView({ block:'start' });
  }
  function resetPage() { page = 1; void render(); }
  function showCart(open) {
    const drawer = $('cart-drawer');
    if (open) previousFocus = document.activeElement;
    drawer.classList.toggle('open', open);
    $('overlay').classList.toggle('open', open);
    drawer.setAttribute('aria-hidden', String(!open));
    drawer.inert = !open;
    if (open) $('cart-close').focus();
    else previousFocus?.focus();
  }

  grid.addEventListener('click', event => {
    const sku = event.target.closest('[data-add]')?.dataset.add;
    if (!sku) return;
    if (cart.includes(sku)) return notice('Dit artikel bevindt zich al in uw winkelmand.');
    if (cart.length >= 20) return notice('U kunt maximaal 20 artikelen per bestelling afrekenen.');
    cart.push(sku);
    saveCart();
    notice(products.get(sku).title + ' toegevoegd');
  });
  $('cart-items').addEventListener('click', event => {
    const sku = event.target.closest('[data-remove]')?.dataset.remove;
    if (sku) { cart = cart.filter(key => key !== sku); saveCart(); $('cart-close').focus(); }
  });
  $('cart-open').addEventListener('click', () => showCart(true));
  $('cart-close').addEventListener('click', () => showCart(false));
  $('overlay').addEventListener('click', () => showCart(false));
  document.addEventListener('keydown', event => {
    if (!$('cart-drawer').classList.contains('open')) return;
    if (event.key === 'Escape') showCart(false);
    if (event.key !== 'Tab') return;
    const controls = [...$('cart-drawer').querySelectorAll('a[href], button:not(:disabled)')];
    if (event.shiftKey && document.activeElement === controls[0]) {
      event.preventDefault();
      controls.at(-1).focus();
    } else if (!event.shiftKey && document.activeElement === controls.at(-1)) {
      event.preventDefault();
      controls[0].focus();
    }
  });
  $('checkout-button').addEventListener('click', () => {
    if (cart.length) location.assign('/checkout?' + new URLSearchParams({ items:cart.join(',') }));
  });
  $('filter-toggle').addEventListener('click', () => {
    const open = $('catalog-sidebar').classList.toggle('open');
    $('filter-toggle').setAttribute('aria-expanded', String(open));
    $('filter-toggle').querySelector('span').textContent = open ? '−' : '+';
  });
  $('categories').addEventListener('click', event => {
    const link = event.target.closest('[data-category]');
    if (!link || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    const previous = $('categories').querySelector('.active');
    previous.classList.remove('active');
    previous.removeAttribute('aria-current');
    link.classList.add('active');
    link.setAttribute('aria-current','true');
    category = link.dataset.category;
    $('shop-title').textContent = category === 'all' ? 'Alle werkboeken' : link.textContent;
    if ($('catalog-sidebar').classList.contains('open') && matchMedia('(max-width: 850px)').matches) {
      $('filter-toggle').click();
      $('filter-toggle').focus();
    }
    resetPage();
  });
  $('product-search').addEventListener('input', () => {
    clearTimeout(typing);
    typing = setTimeout(resetPage, 160);
  });
  $('search-clear').addEventListener('click', () => { $('product-search').value = ''; resetPage(); });
  $('sort-select').addEventListener('change', resetPage);
  $('license-select').addEventListener('change', resetPage);
  $('search-toggle').addEventListener('click', () => { $('product-search').scrollIntoView({ block:'center' }); $('product-search').focus(); });
  $('previous-page').addEventListener('click', () => changePage(-1));
  $('next-page').addEventListener('click', () => changePage(1));
  $('menu-toggle').addEventListener('click', () => {
    $('menu-toggle').setAttribute('aria-expanded', String($('main-nav').classList.toggle('open')));
  });
  $('main-nav').addEventListener('click', event => {
    const link = event.target.closest('a');
    if (!link) return;
    if (link.hash === '#categories' && matchMedia('(max-width: 850px)').matches) {
      event.preventDefault();
      if (!$('catalog-sidebar').classList.contains('open')) $('filter-toggle').click();
      $('filter-toggle').scrollIntoView({ block:'center' });
      $('filter-toggle').focus({ preventScroll:true });
    }
    $('main-nav').classList.remove('open');
    $('menu-toggle').setAttribute('aria-expanded','false');
  });
  $('year').textContent = new Date().getFullYear();
  $('cart-drawer').inert = true;
  renderCart();
  void loadCart();
  void render();
  if (new URLSearchParams(location.search).get('winkelmand') === '1') showCart(true);
}
const detailButton = document.querySelector('[data-add-detail]');
if (detailButton) {
  detailButton.hidden = false;
  detailButton.addEventListener('click', () => {
    const status = $('detail-status');
    const sku = detailButton.dataset.addDetail;
    const stored = readCart();
    status.hidden = false;
    if (stored.includes(sku)) {
      status.textContent = 'Dit artikel bevindt zich al in uw winkelmand.';
    } else if (stored.length >= 20) {
      status.textContent = 'U kunt maximaal 20 artikelen per bestelling afrekenen.';
    } else {
      try {
        localStorage.setItem(cartKey, JSON.stringify([...stored,sku]));
        status.textContent = 'Toegevoegd aan uw winkelmand.';
      } catch {
        status.textContent = 'Uw winkelmand kon niet worden opgeslagen. U kunt direct afrekenen.';
        return;
      }
    }
    const link = document.createElement('a');
    link.href = '/?winkelmand=1#shop';
    link.textContent = 'Winkelmand bekijken';
    status.append(' ',link);
  });
}
const purchased = document.querySelector('[data-purchased]');
if (purchased) {
  try {
    const removed = new Set(purchased.dataset.purchased.split(','));
    localStorage.setItem(cartKey, JSON.stringify(readCart().filter(sku => !removed.has(sku))));
  } catch {}
}
