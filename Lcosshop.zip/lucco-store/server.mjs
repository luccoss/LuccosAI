import { createServer } from 'node:http';
import { createHmac, randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import { createReadStream, readFileSync, readdirSync, statSync, writeFileSync } from 'node:fs';
import { pipeline } from 'node:stream/promises';
import { resolve, basename } from 'node:path';
import { base, categories, db, mode, port, privateFile, publicProduct, published, root, seed, seller, skuPattern, transaction } from './store.mjs';
import { confirmed, demoResult, refresh, startPayment } from './payment.mjs';
import { checkoutView, consent, dateTime, h, invoiceView, legalLink, money, page, productView } from './views.mjs';

const strictUrl = value => {
  try { return new URL(value).protocol === 'https:'; } catch { return false; }
};
const secret = process.env.LUCCO_SECRET || (mode === 'demo' ? randomBytes(32).toString('hex') : '');
const mailbox = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
if (mode !== 'demo' && (!strictUrl(base) || new URL(base).origin !== base || secret.length < 32 ||
    !process.env.MOLLIE_API_KEY?.startsWith(mode + '_'))) throw Error('Stel BASE_URL, LUCCO_SECRET en de juiste Mollie-sleutel in.');
if (mode === 'live' && (Object.values(seller).some(value => !value.trim()) ||
    !['privacy_url','terms_url','returns_url'].every(key => strictUrl(seller[key])) ||
    !mailbox.test(seller.email) || !process.env.RESEND_API_KEY || !mailbox.test(process.env.MAIL_FROM || ''))) {
  throw Error('Vul de bedrijfsgegevens, beleidslinks en e-mailconfiguratie in voor live verkoop.');
}

seed();
if (mode === 'demo') writeFileSync(resolve(root, 'files/demo.txt'), 'LUCCO — testdownload. Dit is een eigen demonstratiebestand.\n');
const home = readFileSync(new URL('./public/index.html', import.meta.url), 'utf8');
const assets = Object.fromEntries(['styles.css','app.js'].map(name => ['/' + name, readFileSync(new URL('./public/' + name, import.meta.url))]));
const accessPattern = /^[a-f0-9]{48}$/;
const mediaDirectory = new URL('./public/media/', import.meta.url);
const mediaAssets = new Set(readdirSync(mediaDirectory).filter(name => /^[a-z0-9-]+\.webp$/.test(name)));
const attempts = /^[a-f0-9-]{36}$/;
const DEMO_NOTICE = '<div class="preview-strip">Demowinkel · Betalingen worden gesimuleerd</div>';
const TEST_NOTICE = '<div class="preview-strip">Testomgeving · Betalingen worden gesimuleerd</div>';
const statuses = {
  open:'Wacht op betaling', pending:'Betaling in behandeling', authorized:'Betaling wordt verwerkt',
  paid:'Betaald', failed:'Betaling mislukt', expired:'Betaling verlopen', canceled:'Betaling geannuleerd',
  refunded:'Terugbetaald', chargeback:'Betaling teruggeboekt', review:'Gedeeltelijk terugbetaald · in beoordeling'
};
const orderByAccess = access => accessPattern.test(access || '') && db.prepare('SELECT * FROM orders WHERE access=?').get(access);
const withdrawalFor = id => db.prepare('SELECT * FROM withdrawals WHERE order_id=?').get(id);
const item = sku => {
  const row = db.prepare('SELECT data FROM products WHERE sku=? AND published=1').get(sku);
  return row && JSON.parse(row.data);
};

const sign = (...values) => createHmac('sha256', secret).update(JSON.stringify(values)).digest('hex');
const verify = (value, expected) => /^[a-f0-9]{64}$/.test(value || '') &&
  timingSafeEqual(Buffer.from(value), Buffer.from(expected));
function send(res, code, data, type = 'text/html; charset=utf-8') {
  res.writeHead(code, { 'Content-Type': type });
  res.end(data);
}
const json = (res, data) => send(res, 200, JSON.stringify(data), 'application/json; charset=utf-8');
function redirect(res, href) {
  res.writeHead(303, { Location:href });
  res.end();
}
async function fields(req) {
  if (!req.headers['content-type']?.startsWith('application/x-www-form-urlencoded')) throw clientError('Ongeldig formulier.', 415);
  let raw = '';
  for await (const chunk of req) {
    raw += chunk.toString();
    if (raw.length > 16_384) throw clientError('Invoer te groot.', 413);
  }
  return new URLSearchParams(raw);
}
function clientError(message, status = 400) {
  return Object.assign(new Error(message), { status });
}
function skus(value) {
  const parts = [...new Set((value || '').split(',').filter(Boolean))];
  if (!parts.length || parts.length > 20 || !parts.every(sku => skuPattern.test(sku))) throw clientError('Kies 1 tot 20 verschillende producten.');
  return parts;
}
function cart(items) {
  return skus(items).map(sku => {
    const product = item(sku);
    if (!product) throw clientError('Een product in uw winkelmand is niet meer beschikbaar.');
    try { privateFile(product.file); } catch { throw clientError('Een download is tijdelijk niet beschikbaar.', 409); }
    const { title, file, gross, vat, license, version } = product;
    return { sku, title, file, gross, vat, license, version, tax:gross - Math.round(gross * 100 / (100 + vat)) };
  });
}
function quoteFor(lines, attempt) { return sign('quote', attempt, lines); }
function showCheckout(res, lines, message = '', status = 200) {
  const attempt = randomUUID();
  send(res, status, checkoutView(lines, quoteFor(lines, attempt), attempt, message));
}
function customerFrom(form) {
  const customer = Object.fromEntries(['name','email','address','postcode','city'].map(key => [key, form.get(key)?.trim() || '']));
  const lengths = { name:120, email:254, address:150, postcode:7, city:100 };
  if (Object.entries(customer).some(([k,v]) => !v || v.length > lengths[k] || /[\r\n\0]/.test(v)) ||
      !mailbox.test(customer.email) || !/^\d{4} ?[a-z]{2}$/i.test(customer.postcode) || form.get('consent') !== 'yes') {
    throw clientError('Controleer uw factuurgegevens en bevestig uw toestemming voor directe levering.');
  }
  customer.postcode = customer.postcode.toUpperCase();
  customer.consent = consent;
  customer.consent_at = new Date().toISOString();
  return customer;
}
function catalog(params) {
  const category = params.get('category');
  const needle = (params.get('q') || '').slice(0,100).trim().toLowerCase();
  const license = params.get('license');
  const key = params.get('sort');
  const available = published();
  const rows = available.filter(p => (!category || category === 'all' || p.category === category) &&
    (!license || p.license_type === license) &&
    (!needle || [p.title,p.summary,p.category_label,p.format,p.tags].join(' ').toLowerCase().includes(needle)));
  if (key === 'price-low') rows.sort((a,b) => a.gross - b.gross);
  if (key === 'price-high') rows.sort((a,b) => b.gross - a.gross);
  const current = Math.min(Math.max(1, Math.floor(Number(params.get('page')) || 1)), Math.max(1, Math.ceil(rows.length / 24)));
  return { hasReseller:available.some(product => product.license_type === 'reseller'), total:rows.length, page:current, pageSize:24, products:rows.slice((current-1)*24, current*24).map(publicProduct) };
}
function orderView(order, canCheck = true) {
  const prefix = '/order/' + order.access;
  let downloads = '';
  const withdrawal = withdrawalFor(order.id);
  if (!withdrawal && confirmed(order) && (mode !== 'live' || order.mailed)) {
    const expiry = Math.floor(Date.now()/1000) + 600;
    downloads = `<h2>Uw downloads</h2><ul class="downloads">${JSON.parse(order.lines).map(line => `<li><a href="${prefix}/download/${h(line.sku)}?exp=${expiry}&amp;sig=${sign('download',order.access,line.sku,expiry)}">Download ${h(line.title)} ↗</a><small>${h(line.license)}</small></li>`).join('')}</ul>`;
  } else if (!withdrawal && confirmed(order)) {
    downloads = '<p>Uw downloads zijn beschikbaar zodra de orderbevestiging is verzonden.</p>';
  }
  const retry = ['failed','canceled','expired'].includes(order.status)
    ? `<a class="button button-dark" href="/checkout?items=${h(JSON.parse(order.lines).map(line => line.sku).join(','))}">Opnieuw afrekenen ↗</a>`
    : '';
  const invoice = order.invoice ? `<a href="${prefix}/invoice">Factuur bekijken ↗</a>` : '';
  return page('Bestelling', `<section class="order-panel flow" ${confirmed(order) ? `data-purchased="${h(JSON.parse(order.lines).map(line => line.sku).join(','))}"` : ''}><h1>Bestelling ${order.id}</h1>
    <p class="lead">${h(statuses[order.status])} · ${money(order.gross)}</p>
    ${!canCheck ? '<p>De betaalprovider is even onbereikbaar. Probeer het later opnieuw.</p>' : ''}
    ${downloads}${invoice}${retry}
    ${withdrawal ? `<p>Herroeping ontvangen op ${dateTime(withdrawal.created)}.</p>` : order.paid && order.status !== 'refunded' ? `<a href="${prefix}/withdraw">Koop ongedaan maken</a>` : ''}
    ${['open','pending','authorized','review'].includes(order.status) || (order.status === 'paid' && !order.mailed)
      ? `<a href="${prefix}">Status vernieuwen ↻</a>` : ''}</section>`);
}
function withdrawalPage(order) {
  const record = order && withdrawalFor(order.id);
  if (record) return page('Koop ongedaan maken', `<section class="order-panel flow"><h1>Herroeping ontvangen</h1>
    <p>Bestelling ${order.id} · ${dateTime(record.created)}. U ontvangt een bevestiging per e-mail.</p>
    <a href="/order/${order.access}">Terug naar bestelling ↗</a></section>`);
  return page('Koop ongedaan maken', `<form class="order-panel flow" method="post">
    <h1>Koop ongedaan maken</h1>${order ? `<p>Bestelling ${order.id} · ${money(order.gross)}</p>` :
      '<label>Bestelnummer<input name="order" inputmode="numeric" required maxlength="12"></label><label>E-mailadres van de bestelling<input name="email" type="email" required maxlength="254"></label>'}
    <button class="button button-dark">Koop ongedaan maken</button></form>`);
}
let mailing = false;
async function mailOrders() {
  if (mailing) return;
  mailing = true;
  try {
    const pending = db.prepare(`
      SELECT id, access, customer, seller, gross, NULL AS withdrawn, mail_started FROM orders
        WHERE status='paid' AND mailed IS NULL AND mail_after<=?
        AND NOT EXISTS(SELECT 1 FROM withdrawals WHERE order_id=orders.id)
      UNION ALL
      SELECT orders.id, access, customer, seller, gross, withdrawals.created AS withdrawn, withdrawals.mail_started
        FROM withdrawals JOIN orders ON orders.id=withdrawals.order_id
        WHERE withdrawals.mailed IS NULL AND withdrawals.mail_after<=?
      ORDER BY withdrawn DESC, id LIMIT 10`).all(Date.now(), Date.now());
    for (const order of pending) {
      if (!process.env.RESEND_API_KEY && mode === 'test') continue;
      const table = order.withdrawn ? 'withdrawals' : 'orders';
      const idField = order.withdrawn ? 'order_id' : 'id';
      const type = order.withdrawn ? 'withdrawal' : 'confirmation';
      const customer = JSON.parse(order.customer);
      const prefix = base + '/order/' + order.access;
      const contact = JSON.parse(order.seller).email || 'Neem contact op met LUCCO.';
      const subject = order.withdrawn ? 'LUCCO herroeping bestelling ' + order.id : 'LUCCO bestelling ' + order.id;
      const text = order.withdrawn
        ? `We ontvingen de herroeping van bestelling ${order.id} op ${dateTime(order.withdrawn)} (Nederlandse tijd).\n\nBestelling: ${prefix}\nVragen? ${contact}`
        : `Hartelijk dank voor uw bestelling bij LUCCO.\n\nBestelling ${order.id} · ${money(order.gross)}\nU gaf hiervoor toestemming: ${customer.consent}\n\nBestelling en downloads: ${prefix}\nFactuur: ${prefix}/invoice\nKoop ongedaan maken: ${prefix}/withdraw\n\nVragen? ${contact}`;
      const now = Date.now();
      if (order.mail_started && now - order.mail_started >= 23 * 60 * 60_000) {
        db.prepare(`UPDATE ${table} SET mail_after=?, mail_error='Controleer verzending vóór handmatige herhaling' WHERE ${idField}=?`)
          .run(Number.MAX_SAFE_INTEGER, order.id);
        continue;
      }
      const claimed = db.prepare(`UPDATE ${table} SET mail_started=coalesce(mail_started,?), mail_after=?
        WHERE ${idField}=? AND mailed IS NULL AND mail_after<=?`).run(now, now + 120_000, order.id, now);
      if (!claimed.changes) continue;
      try {
        if (mode === 'demo') {
          const filename = (order.withdrawn ? 'test-withdrawal-' : 'test-email-') + order.id + '.txt';
          writeFileSync(resolve(root, filename), text, { mode:0o600 });
        } else {
          const response = await fetch('https://api.resend.com/emails', {
            method:'POST', headers:{ Authorization:'Bearer ' + process.env.RESEND_API_KEY, 'Content-Type':'application/json',
              'Idempotency-Key':`lucco-${mode}-${type}-${order.access}` },
            body:JSON.stringify({ from:process.env.MAIL_FROM, to:[customer.email], subject, text }),
            signal:AbortSignal.timeout(10_000)
          });
          if (!response.ok) throw Error('Mailprovider HTTP ' + response.status);
        }
        db.prepare(`UPDATE ${table} SET mailed=?, mail_error=NULL WHERE ${idField}=?`).run(Date.now(), order.id);
      } catch (error) {
        db.prepare(`UPDATE ${table} SET mail_error=? WHERE ${idField}=?`).run(error.message, order.id);
      }
    }
  } finally {
    mailing = false;
  }
}
async function syncPayments() {
  const now = Date.now();
  const rows = db.prepare(`SELECT * FROM orders WHERE payment IS NOT NULL AND
    ((status IN ('open','pending','authorized') AND checked<?) OR (status IN ('paid','review') AND checked<?))
    ORDER BY checked LIMIT 15`).all(now - 120_000, now - 86_400_000);
  await Promise.allSettled(rows.map(async order => {
    try { await refresh(order); }
    catch (error) {
      console.error('Betalingscontrole', order.id, error.message);
      db.prepare('UPDATE orders SET checked=? WHERE id=? AND checked=?').run(Date.now(), order.id, order.checked);
    }
  }));
}

async function route(req, res) {
  const url = new URL(req.url, base);
  const { pathname, searchParams } = url;
  const indexable = mode === 'live' && (pathname === '/' || /^\/(p|c)\//.test(pathname) || pathname === '/help');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Content-Security-Policy', "default-src 'self'; img-src 'self' https:; style-src 'self' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; frame-ancestors 'none'; base-uri 'none'");
  if (!indexable) res.setHeader('X-Robots-Tag', 'noindex, nofollow');
  if (req.method === 'POST' && pathname !== '/webhooks/mollie' && req.headers.origin !== base) throw clientError('Ongeldige herkomst.', 403);
  if (req.method === 'GET') {
    if (pathname === '/health') return json(res, { status:'ok', mode });
    if (Object.hasOwn(assets, pathname)) {
      res.setHeader('Cache-Control', 'public, max-age=300');
      return send(res, 200, assets[pathname], pathname.endsWith('.js') ? 'text/javascript; charset=utf-8' : 'text/css; charset=utf-8');
    }
    const mediaName = pathname.startsWith('/media/') && pathname.slice('/media/'.length);
    if (mediaAssets.has(mediaName)) {
      const file = new URL(mediaName, mediaDirectory);
      res.setHeader('Cache-Control', 'public, max-age=86400');
      res.writeHead(200, { 'Content-Type':'image/webp', 'Content-Length':statSync(file).size });
      return pipeline(createReadStream(file), res);
    }
    if (pathname === '/') return send(res, 200, home.replace('<!-- NOTICE -->', mode === 'live' ? '' : mode === 'demo' ? DEMO_NOTICE : TEST_NOTICE)
      .replace('<!-- POLICIES -->', legalLink('privacy','Privacy') + legalLink('terms','Voorwaarden') + legalLink('returns','Levering en herroeping'))
      .replace('<!-- CANONICAL -->', `<link rel="canonical" href="${h(base)}/">`));
    if (pathname === '/api/catalog') return json(res, catalog(searchParams));
    if (pathname === '/api/cart') return json(res, skus(searchParams.get('items')).map(item).filter(Boolean).map(publicProduct));
    if (pathname === '/robots.txt') return send(res, 200, mode === 'live'
      ? `User-agent: *\nAllow: /\nSitemap: ${base}/sitemap.xml\n` : 'User-agent: *\nDisallow: /\n', 'text/plain');
    if (pathname === '/sitemap.xml' && mode === 'live') {
      const paths = ['/', '/help', ...Object.keys(categories).map(key => '/c/' + key), ...published().map(p => '/p/' + p.sku)];
      return send(res, 200, `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${paths.map(path => `<url><loc>${h(base + path)}</loc></url>`).join('')}</urlset>`, 'application/xml');
    }
    if (pathname === '/help') return send(res, 200, page('Klantenservice', `<section class="order-panel flow"><h1>Klantenservice</h1>
      ${seller.email ? `<p>Mail <a href="mailto:${h(seller.email)}">${h(seller.email)}</a>. Vermeld bij vragen over uw bestelling het bestelnummer.</p>
      <p>${h(seller.name)} · ${h(seller.address)} · KVK ${h(seller.kvk)} · btw ${h(seller.vat)}</p>` :
      '<p>Deze winkel draait in een testomgeving.</p>'}<h2 id="returns">Levering en herroeping</h2>
      <p>Uw downloads zijn beschikbaar via de orderbevestiging en op uw bestelpagina.</p>
      <h2 id="privacy">Privacy en opslag</h2><p>Uw winkelmand wordt op dit apparaat bewaard. Bij het afrekenen gebruiken wij uw gegevens voor betaling, levering en administratie.</p>
      <h2 id="terms">Licenties</h2><p>Op iedere productpagina staan de bijbehorende gebruiksrechten.</p></section>`, {canonical:'/help'}));
    const [, section, id, action, sku] = pathname.split('/');
    if (section === 'p' && skuPattern.test(id || '') && pathname === '/p/' + id) {
      const product = item(id);
      if (product) return send(res, 200, productView(publicProduct(product)));
    }
    if (section === 'c' && pathname === '/c/' + id && Object.hasOwn(categories, id)) {
      searchParams.set('category', id);
      const result = catalog(searchParams);
      return send(res, 200, page(categories[id], `<h1>${h(categories[id])}</h1><div class="product-grid category-grid">${result.products.map(p =>
        `<article class="product-card"><a class="product-image" href="/p/${h(p.sku)}"><img loading="lazy" src="${h(p.image_url)}" alt="${h(p.image_alt)}"></a><div class="product-info"><h2><a href="/p/${h(p.sku)}">${h(p.title)}</a></h2><p>${h(p.summary)}</p><strong>${money(p.gross)}</strong></div></article>`).join('') || '<p>Deze categorie is nog leeg.</p>'}</div>
        <nav class="pagination">${result.page > 1 ? `<a href="?page=${result.page-1}">Vorige</a>` : ''}${result.page * result.pageSize < result.total ? `<a href="?page=${result.page+1}">Volgende</a>` : ''}</nav>`,
      { canonical:'/c/' + id + (result.page > 1 ? '?page=' + result.page : '') }));
    }
    if (pathname === '/withdraw') return send(res, 200, withdrawalPage());
    if (pathname === '/checkout') return showCheckout(res, cart(searchParams.get('items')));
    if (section === 'demo-pay' && mode === 'demo' && orderByAccess(id) && pathname === '/demo-pay/' + id) {
      return send(res, 200, page('Betaalsimulatie', `<form class="order-panel flow" method="post"><h1>Betaalsimulatie</h1>
        <p>Test welke status de bestelling krijgt.</p><button class="button button-dark" name="result" value="paid">Geslaagd</button>
        <button class="button" name="result" value="failed">Mislukt</button><button class="button" name="result" value="canceled">Geannuleerd</button>
        <button class="button" name="result" value="refunded">Terugbetaling op betaalde testorder</button></form>`));
    }
    if (section === 'order') {
      let order = orderByAccess(id);
      if (!order) throw clientError('Bestelling niet gevonden.', 404);
      if (action === 'withdraw' && pathname === '/order/' + id + '/withdraw' && order.paid) return send(res, 200, withdrawalPage(order));
      if (action === 'invoice' && pathname === '/order/' + id + '/invoice' && order.invoice) return send(res, 200, invoiceView(order));
      let canCheck = true;
      try {
        if (order.payment && Date.now() - order.checked >= (order.status === 'paid' ? 60_000 : 5000)) order = await refresh(order);
      } catch { canCheck = false; }
      if (action === 'download' && pathname === '/order/' + id + '/download/' + sku) {
        const exp = Number(searchParams.get('exp'));
        const line = JSON.parse(order.lines).find(line => line.sku === sku);
        if (!canCheck || withdrawalFor(order.id) || !confirmed(order) || (mode === 'live' && !order.mailed) || !line ||
            !Number.isSafeInteger(exp) || exp < Date.now()/1000 || !verify(searchParams.get('sig'), sign('download', id, sku, exp))) {
          throw clientError('Download niet beschikbaar. Open uw bestelpagina voor een actuele link.', 403);
        }
        const path = privateFile(line.file);
        db.prepare('INSERT OR IGNORE INTO downloads VALUES (?,?,?)').run(order.id, sku, Date.now());
        res.writeHead(200, { 'Content-Type':'application/octet-stream', 'Content-Length':statSync(path).size,
          'Content-Disposition':"attachment; filename*=UTF-8''" + encodeURIComponent(basename(line.file)).replace(/['()]/g, x => '%' + x.charCodeAt(0).toString(16)) });
        return pipeline(createReadStream(path), res);
      }
      if (pathname === '/order/' + id) return send(res, 200, orderView(order, canCheck));
    }
  }
  const withdrawPath = pathname.match(/^\/order\/([a-f0-9]{48})\/withdraw$/);
  if (req.method === 'POST' && (pathname === '/withdraw' || withdrawPath)) {
    const form = await fields(req);
    const ref = form.get('order')?.trim();
    const email = (form.get('email') || '').trim().toLowerCase();
    const order = withdrawPath ? orderByAccess(withdrawPath[1]) :
      /^\d{1,12}$/.test(ref || '') && mailbox.test(email) &&
        db.prepare("SELECT * FROM orders WHERE id=? AND lower(json_extract(customer,'$.email'))=?").get(Number(ref), email);
    if (order?.paid && ['paid','review'].includes(order.status)) {
      db.prepare('INSERT OR IGNORE INTO withdrawals(order_id,created) VALUES (?,?)').run(order.id, Date.now());
      await mailOrders();
      if (withdrawPath) return redirect(res, pathname);
    }
    return send(res, 200, page('Herroeping', `<section class="order-panel flow"><h1>Herroeping verstuurd</h1>
      <p>Als de bestelling is gevonden en betaald, ontvangt u een bevestiging op het e-mailadres dat bij die bestelling staat.</p>
      <a href="/help">Contact opnemen ↗</a></section>`));
  }
  if (req.method === 'POST' && pathname === '/checkout') {
    const form = await fields(req);
    const lines = cart(form.get('items'));
    const attempt = form.get('attempt');
    if (!attempts.test(attempt || '') || !verify(form.get('quote'), quoteFor(lines, attempt))) {
      return showCheckout(res, lines, 'De bestelling is gewijzigd. Controleer de actuele prijs en probeer opnieuw.', 409);
    }
    const customer = customerFrom(form);
    const order = transaction(() => {
      const existing = db.prepare('SELECT * FROM orders WHERE attempt=?').get(attempt);
      if (existing) return existing;
      const result = db.prepare(`INSERT INTO orders(access,attempt,customer,lines,gross,vat,created,seller)
        VALUES(?,?,?,?,?,?,?,?)`).run(randomBytes(24).toString('hex'), attempt, JSON.stringify(customer), JSON.stringify(lines),
        lines.reduce((sum,p) => sum + p.gross,0), lines.reduce((sum,p) => sum + p.tax,0), Date.now(), JSON.stringify(seller));
      return db.prepare('SELECT * FROM orders WHERE id=?').get(result.lastInsertRowid);
    });
    if (order.status !== 'open') return redirect(res, '/order/' + order.access);
    try { return redirect(res, await startPayment(order)); }
    catch (error) {
      console.error('Checkout', order.id, error.message);
      return send(res, 503, page('Betaalpagina onbereikbaar', `<section class="order-panel flow"><h1>Betaalpagina tijdelijk onbereikbaar</h1>
        <form method="post" action="/checkout">${[...form].filter(([key]) => ['items','attempt','quote','name','email','address','postcode','city','consent'].includes(key))
          .map(([key,value]) => `<input type="hidden" name="${h(key)}" value="${h(value)}">`).join('')}
        <button class="button button-dark">Probeer opnieuw ↗</button></form></section>`));
    }
  }
  if (req.method === 'POST' && pathname === '/webhooks/mollie' && mode !== 'demo') {
    const id = (await fields(req)).get('id');
    if (!/^tr_[\w-]{1,90}$/.test(id || '')) throw clientError('Ongeldige betalingsreferentie.');
    const order = db.prepare('SELECT * FROM orders WHERE payment=?').get(id);
    if (!order) throw clientError('Betaling nog niet bekend.', 503);
    await refresh(order);
    void mailOrders().catch(console.error);
    return send(res, 200, 'OK', 'text/plain');
  }
  if (req.method === 'POST' && mode === 'demo' && pathname.startsWith('/demo-pay/')) {
    const id = pathname.slice('/demo-pay/'.length);
    const order = orderByAccess(id);
    const result = (await fields(req)).get('result');
    if (!order || !['paid','failed','canceled','refunded'].includes(result)) throw clientError('Onbekende testbetaling.');
    demoResult(order,result);
    await mailOrders();
    return redirect(res, '/order/' + id);
  }
  throw clientError('Pagina niet gevonden.', 404);
}
const server = createServer(async (req, res) => {
  try { await route(req, res); }
  catch (error) {
    if (res.headersSent) return res.destroy();
    if (!error.status) console.error(error.message);
    send(res, error.status || 500, page('LUCCO', `<h1>${h(error.status ? error.message : 'Er ging iets mis. Probeer het opnieuw.')}</h1><p><a href="/">Terug naar de winkel ↗</a></p>`));
  }
});
server.requestTimeout = 30_000;
server.listen(port, process.env.HOST || (mode === 'demo' ? '127.0.0.1' : '0.0.0.0'), () => console.log(`LUCCO ${mode} op ${base}`));
setInterval(() => syncPayments().catch(console.error), 60_000).unref();
setInterval(() => mailOrders().catch(console.error), 15_000).unref();
