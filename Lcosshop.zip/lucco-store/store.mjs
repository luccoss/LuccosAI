import { DatabaseSync } from 'node:sqlite';
import { constants, copyFileSync, mkdirSync, readFileSync, realpathSync, statSync } from 'node:fs';
import { resolve, sep } from 'node:path';

export const mode = process.env.LUCCO_MODE || 'demo';
if (!['demo', 'test', 'live'].includes(mode)) throw Error('Onbekende LUCCO_MODE');
export const port = Number(process.env.PORT || 3000);
export const base = (process.env.BASE_URL || `http://127.0.0.1:${port}`).replace(/\/$/, '');
export const root = resolve(process.env.LUCCO_DATA || `./data-${mode}`);
export const seller = Object.fromEntries(
  ['NAME','ADDRESS','VAT','KVK','EMAIL','TERMS_URL','PRIVACY_URL','RETURNS_URL']
    .map(key => [key.toLowerCase(), process.env['SHOP_' + key] || ''])
);
const assets = resolve(root, 'files');
mkdirSync(assets, { recursive: true, mode: 0o700 });
export function privateFile(name) {
  if (!name || resolve(assets, name) === assets) throw Error('Bestand ontbreekt');
  const path = realpathSync(resolve(assets, name));
  if (!path.startsWith(realpathSync(assets) + sep) || !statSync(path).isFile()) {
    throw Error('Ongeldig bestandspad');
  }
  return path;
}
export const db = new DatabaseSync(resolve(root, 'store.sqlite'));
db.exec(`
  PRAGMA journal_mode=WAL;
  PRAGMA busy_timeout=5000;
  CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS products (
    sku TEXT PRIMARY KEY, data TEXT NOT NULL, published INTEGER NOT NULL DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS drafts (
    sku TEXT PRIMARY KEY, data TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY, access TEXT NOT NULL UNIQUE, attempt TEXT NOT NULL UNIQUE,
    customer TEXT NOT NULL, lines TEXT NOT NULL, gross INTEGER NOT NULL, vat INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'open', payment TEXT UNIQUE, checkout TEXT, created INTEGER NOT NULL,
    paid INTEGER, invoice INTEGER UNIQUE, mailed INTEGER, mail_after INTEGER NOT NULL DEFAULT 0,
    mail_started INTEGER, mail_error TEXT, checked INTEGER NOT NULL DEFAULT 0, seller TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS withdrawals (
    order_id INTEGER PRIMARY KEY REFERENCES orders(id), created INTEGER NOT NULL,
    mailed INTEGER, mail_after INTEGER NOT NULL DEFAULT 0, mail_started INTEGER, mail_error TEXT
  );
  CREATE TABLE IF NOT EXISTS downloads (order_id INTEGER NOT NULL, sku TEXT NOT NULL, first_opened INTEGER NOT NULL,
    PRIMARY KEY(order_id,sku));
`);
db.prepare("INSERT OR IGNORE INTO settings VALUES ('mode', ?)").run(mode);
if (db.prepare("SELECT value FROM settings WHERE key='mode'").get().value !== mode) {
  throw Error('Gebruik per omgeving een eigen gegevensmap.');
}
export function transaction(work) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = work();
    db.exec('COMMIT');
    return result;
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
}
export const categories = {
  productivity:'Planning', business:'Ondernemen', wellbeing:'Dagelijks leven', creator:'Contentcreatie',
  ai:'AI en werkprocessen', marketing:'Marketing', design:'Ontwerp', finance:'Financieel overzicht', bundles:'Bundels'
};
export const skuPattern = /^[a-zA-Z0-9][a-zA-Z0-9_-]{0,79}$/;
const cents = value => Math.round(Number(value) * 100);
export function validate(product) {
  for (const field of ['sku','title','category','summary','description','format','image_url','image_alt',
    'language','compatibility','license','rights_ref','image_rights_ref','reviewed_by','file','version']) {
    if (typeof product[field] !== 'string' || !product[field].trim()) throw Error(`Veld ontbreekt: ${field}`);
  }
  if (!skuPattern.test(product.sku) || !Object.hasOwn(categories, product.category)) throw Error('Ongeldige SKU of categorie');
  const localMedia = /^\/media\/[a-z0-9-]+\.webp$/;
  const localImage = value => typeof value === 'string' && localMedia.test(value) &&
    statSync(new URL('./public' + value, import.meta.url), { throwIfNoEntry:false })?.isFile();
  if (!(localImage(product.image_url) || /^https:\/\/[^\s]+$/.test(product.image_url)) || !/^[1-9]\d{0,4}\.\d{2}$|^0\.[0-9]{2}$/.test(String(product.price)) || cents(product.price) < 1) {
    throw Error('Gebruik een HTTPS-afbeelding of meegeleverde omslag en een EUR-prijs met twee decimalen.');
  }
  if (product.preview_url && !localImage(product.preview_url)) throw Error('Voorbeeldafbeelding ontbreekt.');
  if (!Number.isInteger(product.vat) || product.vat < 0 || product.vat > 100) throw Error('Ongeldig btw-tarief');
  if (!['gebruik','reseller'].includes(product.license_type)) throw Error('Kies gebruik of reseller voor license_type.');
  if (product.license_type === 'reseller' && !String(product.downstream_rights || '').trim()) throw Error('Leg de doorverkooprechten expliciet vast.');
  if (!Array.isArray(product.includes) || !product.includes.length || !product.includes.every(item => typeof item === 'string' && item.trim())) throw Error('Beschrijf de inhoud.');
  const size = statSync(privateFile(product.file)).size;
  if (!size) throw Error('Leeg downloadbestand.');
  if (product.discount_from && !(Number(product.discount_from) > Number(product.price))) throw Error('Ongeldige referentieprijs.');
  return { ...product, bytes:size, category_label:categories[product.category], gross:cents(product.price) };
}
export function published() {
  return db.prepare('SELECT data FROM products WHERE published=1 ORDER BY rowid').all().map(row => JSON.parse(row.data));
}
export function publicProduct(product) {
  const fields = ['sku','category','category_label','title','summary','description','price','gross','image_url','image_alt',
    'format','preview_url','includes','language','compatibility','license','license_type','downstream_rights','version','bytes','discount_from','tags'];
  return Object.fromEntries(fields.filter(key => product[key] !== undefined).map(key => [key, product[key]]));
}
export function editionDrafts() {
  const products = JSON.parse(readFileSync(new URL('./catalog-edition.json', import.meta.url)));
  mkdirSync(resolve(assets,'lucco-editie'), { recursive:true, mode:0o700 });
  return products.map(product => {
    const name = product.sku + '-v1.pdf';
    if (product.file !== 'lucco-editie/' + name || !skuPattern.test(product.sku)) throw Error('Ongeldig artikel in de editie');
    try {
      copyFileSync(new URL('./downloads/' + name, import.meta.url), resolve(assets, product.file), constants.COPYFILE_EXCL);
    } catch (error) {
      if (error.code !== 'EEXIST') throw error;
    }
    return {
      ...product, license_type:'gebruik',
      license:'Voor eigen gebruik of gebruik binnen uw organisatie. Doorverkoop en openbare verspreiding vallen buiten deze licentie.',
      rights_ref:'LUCCO cataloguseditie 1.0', image_rights_ref:'LUCCO cataloguseditie 1.0'
    };
  });
}
export function seed() {
  if (mode !== 'demo') return;
  const products = editionDrafts();
  transaction(() => {
    if (db.prepare("SELECT 1 FROM settings WHERE key='edition-2026-11'").get()) return;
    const legacy = JSON.parse(readFileSync(new URL('./demo-products.json', import.meta.url)));
    const retire = db.prepare("UPDATE products SET published=0 WHERE sku=? AND json_extract(data,'$.file')='demo.txt'");
    for (const product of legacy) retire.run(product.sku);
    const insert = db.prepare('INSERT OR IGNORE INTO products VALUES (?, ?, 1)');
    for (const product of products) {
      const sample = validate({ ...product, vat:21, reviewed_by:'Interne demo' });
      insert.run(sample.sku, JSON.stringify(sample));
    }
    db.exec("INSERT INTO settings VALUES ('edition-2026-11', '1')");
  });
}
