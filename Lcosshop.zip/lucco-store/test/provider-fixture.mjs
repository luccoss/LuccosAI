import assert from 'node:assert/strict';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

if (process.env.MOLLIE_API_KEY === 'test_fixture') {
  const data = process.env.LUCCO_DATA;
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async (url, options) => {
    if (url === 'https://api.mollie.com/v2/payments') {
      const request = JSON.parse(options.body);
      assert.equal(request.amount.value,'12.10');
      assert.match(options.headers['Idempotency-Key'], /^[a-f0-9-]{36}$/);
      writeFileSync(resolve(data,'fixture-order.txt'),new URL(request.redirectUrl).pathname);
      assert.equal(request.webhookUrl,'https://shop.example.com/webhooks/mollie');
      return Response.json({ id:'tr_fixture', _links:{ checkout:{ href:'https://www.mollie.com/checkout/test' } } });
    }
    if (url === 'https://api.mollie.com/v2/payments/tr_fixture') {
      const file = resolve(data,'fixture-status.txt');
      const state = existsSync(file) ? readFileSync(file,'utf8') : 'open';
      return Response.json({ id:'tr_fixture', mode:'test', metadata:{ order:1 },
        amount:{ currency:'EUR', value:state === 'bad-amount' ? '12.11' : '12.10' },
        status:['paid','refunded','bad-amount'].includes(state) ? 'paid' : 'open',
        ...(state === 'refunded' ? { amountRefunded:{ currency:'EUR', value:'12.10' } } : {}) });
    }
    if (url === 'https://api.resend.com/emails') {
      const request = JSON.parse(options.body);
      assert.ok(options.headers['Idempotency-Key']);
      writeFileSync(resolve(data,'fixture-mail.txt'),request.text);
      return Response.json({ id:'test-message' });
    }
    return originalFetch(url, options);
  };
}
